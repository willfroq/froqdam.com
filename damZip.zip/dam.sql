-- MariaDB dump 10.19  Distrib 10.8.3-MariaDB, for osx10.16 (x86_64)
--
-- Host: 127.0.0.1    Database: froq_pimcore
-- ------------------------------------------------------
-- Server version	10.8.3-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_logs`
--

DROP TABLE IF EXISTS `application_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_logs` (
                                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                                    `pid` int(11) DEFAULT NULL,
                                    `timestamp` datetime NOT NULL,
                                    `message` text DEFAULT NULL,
                                    `priority` enum('emergency','alert','critical','error','warning','notice','info','debug') DEFAULT NULL,
                                    `fileobject` varchar(1024) DEFAULT NULL,
                                    `info` varchar(1024) DEFAULT NULL,
                                    `component` varchar(190) DEFAULT NULL,
                                    `source` varchar(190) DEFAULT NULL,
                                    `relatedobject` int(11) unsigned DEFAULT NULL,
                                    `relatedobjecttype` enum('object','document','asset') DEFAULT NULL,
                                    `maintenanceChecked` tinyint(1) DEFAULT NULL,
                                    PRIMARY KEY (`id`),
                                    KEY `component` (`component`),
                                    KEY `timestamp` (`timestamp`),
                                    KEY `relatedobject` (`relatedobject`),
                                    KEY `priority` (`priority`),
                                    KEY `maintenanceChecked` (`maintenanceChecked`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_logs`
--

LOCK TABLES `application_logs` WRITE;
/*!40000 ALTER TABLE `application_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
                          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                          `parentId` int(11) unsigned DEFAULT NULL,
                          `type` varchar(20) DEFAULT NULL,
                          `filename` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
                          `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                          `mimetype` varchar(190) DEFAULT NULL,
                          `creationDate` int(11) unsigned DEFAULT NULL,
                          `modificationDate` int(11) unsigned DEFAULT NULL,
                          `userOwner` int(11) unsigned DEFAULT NULL,
                          `userModification` int(11) unsigned DEFAULT NULL,
                          `customSettings` longtext DEFAULT NULL,
                          `hasMetaData` tinyint(1) NOT NULL DEFAULT 0,
                          `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
                          PRIMARY KEY (`id`),
                          UNIQUE KEY `fullpath` (`path`,`filename`),
                          KEY `parentId` (`parentId`),
                          KEY `filename` (`filename`),
                          KEY `modificationDate` (`modificationDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES
    (1,0,'folder','','/',NULL,1657535401,1657535401,1,1,NULL,0,0);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_image_thumbnail_cache`
--

DROP TABLE IF EXISTS `assets_image_thumbnail_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_image_thumbnail_cache` (
                                                `cid` int(11) unsigned NOT NULL,
                                                `name` varchar(190) CHARACTER SET ascii NOT NULL,
                                                `filename` varchar(190) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
                                                `modificationDate` int(11) unsigned DEFAULT NULL,
                                                `filesize` int(10) unsigned DEFAULT NULL,
                                                `width` smallint(5) unsigned DEFAULT NULL,
                                                `height` smallint(5) unsigned DEFAULT NULL,
                                                PRIMARY KEY (`cid`,`name`,`filename`),
                                                CONSTRAINT `FK_assets_image_thumbnail_cache_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_image_thumbnail_cache`
--

LOCK TABLES `assets_image_thumbnail_cache` WRITE;
/*!40000 ALTER TABLE `assets_image_thumbnail_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_image_thumbnail_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_metadata`
--

DROP TABLE IF EXISTS `assets_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_metadata` (
                                   `cid` int(11) unsigned NOT NULL,
                                   `name` varchar(190) NOT NULL,
                                   `language` varchar(10) CHARACTER SET ascii NOT NULL DEFAULT '',
                                   `type` enum('input','textarea','asset','document','object','date','select','checkbox') DEFAULT NULL,
                                   `data` longtext DEFAULT NULL,
                                   PRIMARY KEY (`cid`,`name`,`language`),
                                   KEY `name` (`name`),
                                   CONSTRAINT `fk_assets_metadata_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_metadata`
--

LOCK TABLES `assets_metadata` WRITE;
/*!40000 ALTER TABLE `assets_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_data_hub_data_importer_delta_cache`
--

DROP TABLE IF EXISTS `bundle_data_hub_data_importer_delta_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_data_hub_data_importer_delta_cache` (
                                                             `configName` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
                                                             `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
                                                             `hash` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
                                                             PRIMARY KEY (`configName`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_data_hub_data_importer_delta_cache`
--

LOCK TABLES `bundle_data_hub_data_importer_delta_cache` WRITE;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_delta_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_delta_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_data_hub_data_importer_last_execution`
--

DROP TABLE IF EXISTS `bundle_data_hub_data_importer_last_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_data_hub_data_importer_last_execution` (
                                                                `configName` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
                                                                `lastExecutionDate` int(11) DEFAULT NULL,
                                                                PRIMARY KEY (`configName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_data_hub_data_importer_last_execution`
--

LOCK TABLES `bundle_data_hub_data_importer_last_execution` WRITE;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_last_execution` DISABLE KEYS */;
INSERT INTO `bundle_data_hub_data_importer_last_execution` VALUES
    ('test1',1660037366);
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_last_execution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_data_hub_data_importer_queue`
--

DROP TABLE IF EXISTS `bundle_data_hub_data_importer_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_data_hub_data_importer_queue` (
                                                       `id` bigint(20) NOT NULL AUTO_INCREMENT,
                                                       `timestamp` bigint(20) DEFAULT NULL,
                                                       `configName` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       `data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       `executionType` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       `jobType` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       `dispatched` bigint(20) DEFAULT NULL,
                                                       `workerId` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       PRIMARY KEY (`id`),
                                                       KEY `bundle_index_queue_configName_index` (`configName`),
                                                       KEY `bundle_index_queue_configName_index_executionType` (`configName`,`executionType`),
                                                       KEY `bundle_index_queue_executiontype_workerId` (`executionType`,`workerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_data_hub_data_importer_queue`
--

LOCK TABLES `bundle_data_hub_data_importer_queue` WRITE;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_items`
--

DROP TABLE IF EXISTS `cache_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_items` (
                               `item_id` varbinary(255) NOT NULL,
                               `item_data` mediumblob NOT NULL,
                               `item_lifetime` int(10) unsigned DEFAULT NULL,
                               `item_time` int(10) unsigned NOT NULL,
                               PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_items`
--

LOCK TABLES `cache_items` WRITE;
/*!40000 ALTER TABLE `cache_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes` (
                           `id` varchar(50) NOT NULL,
                           `name` varchar(190) NOT NULL DEFAULT '',
                           PRIMARY KEY (`id`),
                           UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_collectionrelations`
--

DROP TABLE IF EXISTS `classificationstore_collectionrelations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_collectionrelations` (
                                                           `colId` int(11) unsigned NOT NULL,
                                                           `groupId` int(11) unsigned NOT NULL,
                                                           `sorter` int(10) DEFAULT 0,
                                                           PRIMARY KEY (`colId`,`groupId`),
                                                           KEY `FK_classificationstore_collectionrelations_groups` (`groupId`),
                                                           CONSTRAINT `FK_classificationstore_collectionrelations_groups` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_collectionrelations`
--

LOCK TABLES `classificationstore_collectionrelations` WRITE;
/*!40000 ALTER TABLE `classificationstore_collectionrelations` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_collectionrelations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_collections`
--

DROP TABLE IF EXISTS `classificationstore_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_collections` (
                                                   `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                                   `storeId` int(11) DEFAULT NULL,
                                                   `name` varchar(255) NOT NULL DEFAULT '',
                                                   `description` varchar(255) DEFAULT NULL,
                                                   `creationDate` int(11) unsigned DEFAULT 0,
                                                   `modificationDate` int(11) unsigned DEFAULT 0,
                                                   PRIMARY KEY (`id`),
                                                   KEY `storeId` (`storeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_collections`
--

LOCK TABLES `classificationstore_collections` WRITE;
/*!40000 ALTER TABLE `classificationstore_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_groups`
--

DROP TABLE IF EXISTS `classificationstore_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_groups` (
                                              `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                              `storeId` int(11) DEFAULT NULL,
                                              `parentId` int(11) unsigned NOT NULL DEFAULT 0,
                                              `name` varchar(190) NOT NULL DEFAULT '',
                                              `description` varchar(255) DEFAULT NULL,
                                              `creationDate` int(11) unsigned DEFAULT 0,
                                              `modificationDate` int(11) unsigned DEFAULT 0,
                                              PRIMARY KEY (`id`),
                                              KEY `storeId` (`storeId`),
                                              KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_groups`
--

LOCK TABLES `classificationstore_groups` WRITE;
/*!40000 ALTER TABLE `classificationstore_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_keys`
--

DROP TABLE IF EXISTS `classificationstore_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_keys` (
                                            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                            `storeId` int(11) DEFAULT NULL,
                                            `name` varchar(190) NOT NULL DEFAULT '',
                                            `title` varchar(255) NOT NULL DEFAULT '',
                                            `description` text DEFAULT NULL,
                                            `type` varchar(190) DEFAULT NULL,
                                            `creationDate` int(11) unsigned DEFAULT 0,
                                            `modificationDate` int(11) unsigned DEFAULT 0,
                                            `definition` longtext DEFAULT NULL,
                                            `enabled` tinyint(1) DEFAULT NULL,
                                            PRIMARY KEY (`id`),
                                            KEY `name` (`name`),
                                            KEY `enabled` (`enabled`),
                                            KEY `type` (`type`),
                                            KEY `storeId` (`storeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_keys`
--

LOCK TABLES `classificationstore_keys` WRITE;
/*!40000 ALTER TABLE `classificationstore_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_relations`
--

DROP TABLE IF EXISTS `classificationstore_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_relations` (
                                                 `groupId` int(11) unsigned NOT NULL,
                                                 `keyId` int(11) unsigned NOT NULL,
                                                 `sorter` int(11) DEFAULT NULL,
                                                 `mandatory` tinyint(1) DEFAULT NULL,
                                                 PRIMARY KEY (`groupId`,`keyId`),
                                                 KEY `FK_classificationstore_relations_classificationstore_keys` (`keyId`),
                                                 KEY `mandatory` (`mandatory`),
                                                 CONSTRAINT `FK_classificationstore_relations_classificationstore_groups` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE,
                                                 CONSTRAINT `FK_classificationstore_relations_classificationstore_keys` FOREIGN KEY (`keyId`) REFERENCES `classificationstore_keys` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_relations`
--

LOCK TABLES `classificationstore_relations` WRITE;
/*!40000 ALTER TABLE `classificationstore_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_stores`
--

DROP TABLE IF EXISTS `classificationstore_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_stores` (
                                              `id` int(11) NOT NULL AUTO_INCREMENT,
                                              `name` varchar(190) DEFAULT NULL,
                                              `description` longtext DEFAULT NULL,
                                              PRIMARY KEY (`id`),
                                              KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_stores`
--

LOCK TABLES `classificationstore_stores` WRITE;
/*!40000 ALTER TABLE `classificationstore_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_layouts`
--

DROP TABLE IF EXISTS `custom_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_layouts` (
                                  `id` varchar(64) NOT NULL,
                                  `classId` varchar(50) NOT NULL,
                                  `name` varchar(190) DEFAULT NULL,
                                  `description` text DEFAULT NULL,
                                  `creationDate` int(11) unsigned DEFAULT NULL,
                                  `modificationDate` int(11) unsigned DEFAULT NULL,
                                  `userOwner` int(11) unsigned DEFAULT NULL,
                                  `userModification` int(11) unsigned DEFAULT NULL,
                                  `default` tinyint(1) NOT NULL DEFAULT 0,
                                  PRIMARY KEY (`id`),
                                  UNIQUE KEY `name` (`name`,`classId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_layouts`
--

LOCK TABLES `custom_layouts` WRITE;
/*!40000 ALTER TABLE `custom_layouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_layouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependencies`
--

DROP TABLE IF EXISTS `dependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dependencies` (
                                `id` bigint(20) NOT NULL AUTO_INCREMENT,
                                `sourcetype` enum('document','asset','object') NOT NULL DEFAULT 'document',
                                `sourceid` int(11) unsigned NOT NULL DEFAULT 0,
                                `targettype` enum('document','asset','object') NOT NULL DEFAULT 'document',
                                `targetid` int(11) unsigned NOT NULL DEFAULT 0,
                                PRIMARY KEY (`id`),
                                UNIQUE KEY `combi` (`sourcetype`,`sourceid`,`targettype`,`targetid`),
                                KEY `targettype_targetid` (`targettype`,`targetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dependencies`
--

LOCK TABLES `dependencies` WRITE;
/*!40000 ALTER TABLE `dependencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dependencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
                             `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                             `parentId` int(11) unsigned DEFAULT NULL,
                             `type` enum('page','link','snippet','folder','hardlink','email','newsletter','printpage','printcontainer') DEFAULT NULL,
                             `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
                             `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                             `index` int(11) unsigned DEFAULT 0,
                             `published` tinyint(1) unsigned DEFAULT 1,
                             `creationDate` int(11) unsigned DEFAULT NULL,
                             `modificationDate` int(11) unsigned DEFAULT NULL,
                             `userOwner` int(11) unsigned DEFAULT NULL,
                             `userModification` int(11) unsigned DEFAULT NULL,
                             `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
                             PRIMARY KEY (`id`),
                             UNIQUE KEY `fullpath` (`path`,`key`),
                             KEY `parentId` (`parentId`),
                             KEY `key` (`key`),
                             KEY `published` (`published`),
                             KEY `modificationDate` (`modificationDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES
    (1,0,'page','','/',999999,1,1657535401,1657535401,1,1,0);
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_editables`
--

DROP TABLE IF EXISTS `documents_editables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_editables` (
                                       `documentId` int(11) unsigned NOT NULL DEFAULT 0,
                                       `name` varchar(750) CHARACTER SET ascii NOT NULL DEFAULT '',
                                       `type` varchar(50) DEFAULT NULL,
                                       `data` longtext DEFAULT NULL,
                                       PRIMARY KEY (`documentId`,`name`),
                                       CONSTRAINT `fk_documents_editables_documents` FOREIGN KEY (`documentId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_editables`
--

LOCK TABLES `documents_editables` WRITE;
/*!40000 ALTER TABLE `documents_editables` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_editables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_email`
--

DROP TABLE IF EXISTS `documents_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_email` (
                                   `id` int(11) unsigned NOT NULL DEFAULT 0,
                                   `controller` varchar(500) DEFAULT NULL,
                                   `template` varchar(255) DEFAULT NULL,
                                   `to` varchar(255) DEFAULT NULL,
                                   `from` varchar(255) DEFAULT NULL,
                                   `replyTo` varchar(255) DEFAULT NULL,
                                   `cc` varchar(255) DEFAULT NULL,
                                   `bcc` varchar(255) DEFAULT NULL,
                                   `subject` varchar(255) DEFAULT NULL,
                                   `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                   PRIMARY KEY (`id`),
                                   CONSTRAINT `fk_documents_email_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_email`
--

LOCK TABLES `documents_email` WRITE;
/*!40000 ALTER TABLE `documents_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_hardlink`
--

DROP TABLE IF EXISTS `documents_hardlink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_hardlink` (
                                      `id` int(11) unsigned NOT NULL DEFAULT 0,
                                      `sourceId` int(11) DEFAULT NULL,
                                      `propertiesFromSource` tinyint(1) DEFAULT NULL,
                                      `childrenFromSource` tinyint(1) DEFAULT NULL,
                                      PRIMARY KEY (`id`),
                                      KEY `sourceId` (`sourceId`),
                                      CONSTRAINT `fk_documents_hardlink_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_hardlink`
--

LOCK TABLES `documents_hardlink` WRITE;
/*!40000 ALTER TABLE `documents_hardlink` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_hardlink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_link`
--

DROP TABLE IF EXISTS `documents_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_link` (
                                  `id` int(11) unsigned NOT NULL DEFAULT 0,
                                  `internalType` enum('document','asset','object') DEFAULT NULL,
                                  `internal` int(11) unsigned DEFAULT NULL,
                                  `direct` varchar(1000) DEFAULT NULL,
                                  `linktype` enum('direct','internal') DEFAULT NULL,
                                  PRIMARY KEY (`id`),
                                  CONSTRAINT `fk_documents_link_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_link`
--

LOCK TABLES `documents_link` WRITE;
/*!40000 ALTER TABLE `documents_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_newsletter`
--

DROP TABLE IF EXISTS `documents_newsletter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_newsletter` (
                                        `id` int(11) unsigned NOT NULL DEFAULT 0,
                                        `controller` varchar(500) DEFAULT NULL,
                                        `template` varchar(255) DEFAULT NULL,
                                        `from` varchar(255) DEFAULT NULL,
                                        `subject` varchar(255) DEFAULT NULL,
                                        `trackingParameterSource` varchar(255) DEFAULT NULL,
                                        `trackingParameterMedium` varchar(255) DEFAULT NULL,
                                        `trackingParameterName` varchar(255) DEFAULT NULL,
                                        `enableTrackingParameters` tinyint(1) unsigned DEFAULT NULL,
                                        `sendingMode` varchar(20) DEFAULT NULL,
                                        `plaintext` longtext DEFAULT NULL,
                                        `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                        PRIMARY KEY (`id`),
                                        CONSTRAINT `fk_documents_newsletter_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_newsletter`
--

LOCK TABLES `documents_newsletter` WRITE;
/*!40000 ALTER TABLE `documents_newsletter` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_newsletter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_page`
--

DROP TABLE IF EXISTS `documents_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_page` (
                                  `id` int(11) unsigned NOT NULL DEFAULT 0,
                                  `controller` varchar(500) DEFAULT NULL,
                                  `template` varchar(255) DEFAULT NULL,
                                  `title` varchar(255) DEFAULT NULL,
                                  `description` varchar(383) DEFAULT NULL,
                                  `metaData` text DEFAULT NULL,
                                  `prettyUrl` varchar(255) DEFAULT NULL,
                                  `contentMasterDocumentId` int(11) DEFAULT NULL,
                                  `targetGroupIds` varchar(255) NOT NULL DEFAULT '',
                                  `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                  `staticGeneratorEnabled` tinyint(1) unsigned DEFAULT NULL,
                                  `staticGeneratorLifetime` int(11) DEFAULT NULL,
                                  PRIMARY KEY (`id`),
                                  KEY `prettyUrl` (`prettyUrl`),
                                  CONSTRAINT `fk_documents_page_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_page`
--

LOCK TABLES `documents_page` WRITE;
/*!40000 ALTER TABLE `documents_page` DISABLE KEYS */;
INSERT INTO `documents_page` VALUES
    (1,'App\\Controller\\DefaultController::defaultAction','','','',NULL,NULL,NULL,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `documents_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_printpage`
--

DROP TABLE IF EXISTS `documents_printpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_printpage` (
                                       `id` int(11) unsigned NOT NULL DEFAULT 0,
                                       `controller` varchar(500) DEFAULT NULL,
                                       `template` varchar(255) DEFAULT NULL,
                                       `lastGenerated` int(11) DEFAULT NULL,
                                       `lastGenerateMessage` text DEFAULT NULL,
                                       `contentMasterDocumentId` int(11) DEFAULT NULL,
                                       `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                       PRIMARY KEY (`id`),
                                       CONSTRAINT `fk_documents_printpage_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_printpage`
--

LOCK TABLES `documents_printpage` WRITE;
/*!40000 ALTER TABLE `documents_printpage` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_printpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_snippet`
--

DROP TABLE IF EXISTS `documents_snippet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_snippet` (
                                     `id` int(11) unsigned NOT NULL DEFAULT 0,
                                     `controller` varchar(500) DEFAULT NULL,
                                     `template` varchar(255) DEFAULT NULL,
                                     `contentMasterDocumentId` int(11) DEFAULT NULL,
                                     `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                     PRIMARY KEY (`id`),
                                     CONSTRAINT `fk_documents_snippet_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_snippet`
--

LOCK TABLES `documents_snippet` WRITE;
/*!40000 ALTER TABLE `documents_snippet` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_snippet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_translations`
--

DROP TABLE IF EXISTS `documents_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_translations` (
                                          `id` int(11) unsigned NOT NULL DEFAULT 0,
                                          `sourceId` int(11) unsigned NOT NULL DEFAULT 0,
                                          `language` varchar(10) NOT NULL DEFAULT '',
                                          PRIMARY KEY (`sourceId`,`language`),
                                          KEY `id` (`id`),
                                          KEY `language` (`language`),
                                          CONSTRAINT `fk_documents_translations_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_translations`
--

LOCK TABLES `documents_translations` WRITE;
/*!40000 ALTER TABLE `documents_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edit_lock`
--

DROP TABLE IF EXISTS `edit_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edit_lock` (
                             `id` int(11) NOT NULL AUTO_INCREMENT,
                             `cid` int(11) unsigned NOT NULL DEFAULT 0,
                             `ctype` enum('document','asset','object') DEFAULT NULL,
                             `userId` int(11) unsigned NOT NULL DEFAULT 0,
                             `sessionId` varchar(255) DEFAULT NULL,
                             `date` int(11) unsigned DEFAULT NULL,
                             PRIMARY KEY (`id`),
                             KEY `ctype` (`ctype`),
                             KEY `cidtype` (`cid`,`ctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edit_lock`
--

LOCK TABLES `edit_lock` WRITE;
/*!40000 ALTER TABLE `edit_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `edit_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `element_workflow_state`
--

DROP TABLE IF EXISTS `element_workflow_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `element_workflow_state` (
                                          `cid` int(10) NOT NULL DEFAULT 0,
                                          `ctype` enum('document','asset','object') NOT NULL,
                                          `place` text DEFAULT NULL,
                                          `workflow` varchar(100) NOT NULL,
                                          PRIMARY KEY (`cid`,`ctype`,`workflow`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `element_workflow_state`
--

LOCK TABLES `element_workflow_state` WRITE;
/*!40000 ALTER TABLE `element_workflow_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `element_workflow_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_blacklist`
--

DROP TABLE IF EXISTS `email_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_blacklist` (
                                   `address` varchar(190) NOT NULL DEFAULT '',
                                   `creationDate` int(11) unsigned DEFAULT NULL,
                                   `modificationDate` int(11) unsigned DEFAULT NULL,
                                   PRIMARY KEY (`address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_blacklist`
--

LOCK TABLES `email_blacklist` WRITE;
/*!40000 ALTER TABLE `email_blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_log` (
                             `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                             `documentId` int(11) unsigned DEFAULT NULL,
                             `requestUri` varchar(500) DEFAULT NULL,
                             `params` text DEFAULT NULL,
                             `from` varchar(500) DEFAULT NULL,
                             `replyTo` varchar(255) DEFAULT NULL,
                             `to` longtext DEFAULT NULL,
                             `cc` longtext DEFAULT NULL,
                             `bcc` longtext DEFAULT NULL,
                             `sentDate` int(11) unsigned DEFAULT NULL,
                             `subject` varchar(500) DEFAULT NULL,
                             `error` text DEFAULT NULL,
                             PRIMARY KEY (`id`),
                             KEY `sentDate` (`sentDate`,`id`),
                             KEY `document_id` (`documentId`),
                             FULLTEXT KEY `fulltext` (`from`,`to`,`cc`,`bcc`,`subject`,`params`),
                             CONSTRAINT `fk_email_log_documents` FOREIGN KEY (`documentId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary`
--

DROP TABLE IF EXISTS `glossary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glossary` (
                            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                            `language` varchar(10) DEFAULT NULL,
                            `casesensitive` tinyint(1) DEFAULT NULL,
                            `exactmatch` tinyint(1) DEFAULT NULL,
                            `text` varchar(255) DEFAULT NULL,
                            `link` varchar(255) DEFAULT NULL,
                            `abbr` varchar(255) DEFAULT NULL,
                            `site` int(11) unsigned DEFAULT NULL,
                            `creationDate` int(11) unsigned DEFAULT 0,
                            `modificationDate` int(11) unsigned DEFAULT 0,
                            PRIMARY KEY (`id`),
                            KEY `language` (`language`),
                            KEY `site` (`site`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glossary`
--

LOCK TABLES `glossary` WRITE;
/*!40000 ALTER TABLE `glossary` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfig_favourites`
--

DROP TABLE IF EXISTS `gridconfig_favourites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gridconfig_favourites` (
                                         `ownerId` int(11) NOT NULL,
                                         `classId` varchar(50) NOT NULL,
                                         `objectId` int(11) NOT NULL DEFAULT 0,
                                         `gridConfigId` int(11) NOT NULL,
                                         `searchType` varchar(50) NOT NULL DEFAULT '',
                                         `type` enum('asset','object') NOT NULL DEFAULT 'object',
                                         PRIMARY KEY (`ownerId`,`classId`,`searchType`,`objectId`),
                                         KEY `classId` (`classId`),
                                         KEY `searchType` (`searchType`),
                                         KEY `grid_config_id` (`gridConfigId`),
                                         CONSTRAINT `fk_gridconfig_favourites_gridconfigs` FOREIGN KEY (`gridConfigId`) REFERENCES `gridconfigs` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfig_favourites`
--

LOCK TABLES `gridconfig_favourites` WRITE;
/*!40000 ALTER TABLE `gridconfig_favourites` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfig_favourites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfig_shares`
--

DROP TABLE IF EXISTS `gridconfig_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gridconfig_shares` (
                                     `gridConfigId` int(11) NOT NULL,
                                     `sharedWithUserId` int(11) NOT NULL,
                                     PRIMARY KEY (`gridConfigId`,`sharedWithUserId`),
                                     KEY `sharedWithUserId` (`sharedWithUserId`),
                                     KEY `grid_config_id` (`gridConfigId`),
                                     CONSTRAINT `fk_gridconfig_shares_gridconfigs` FOREIGN KEY (`gridConfigId`) REFERENCES `gridconfigs` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfig_shares`
--

LOCK TABLES `gridconfig_shares` WRITE;
/*!40000 ALTER TABLE `gridconfig_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfig_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfigs`
--

DROP TABLE IF EXISTS `gridconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gridconfigs` (
                               `id` int(11) NOT NULL AUTO_INCREMENT,
                               `ownerId` int(11) DEFAULT NULL,
                               `classId` varchar(50) DEFAULT NULL,
                               `name` varchar(50) DEFAULT NULL,
                               `searchType` varchar(50) DEFAULT NULL,
                               `type` enum('asset','object') NOT NULL DEFAULT 'object',
                               `config` longtext DEFAULT NULL,
                               `description` longtext DEFAULT NULL,
                               `creationDate` int(11) DEFAULT NULL,
                               `modificationDate` int(11) DEFAULT NULL,
                               `shareGlobally` tinyint(1) DEFAULT NULL,
                               PRIMARY KEY (`id`),
                               KEY `ownerId` (`ownerId`),
                               KEY `classId` (`classId`),
                               KEY `searchType` (`searchType`),
                               KEY `shareGlobally` (`shareGlobally`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfigs`
--

LOCK TABLES `gridconfigs` WRITE;
/*!40000 ALTER TABLE `gridconfigs` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `http_error_log`
--

DROP TABLE IF EXISTS `http_error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `http_error_log` (
                                  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                  `uri` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                                  `code` int(3) DEFAULT NULL,
                                  `parametersGet` longtext DEFAULT NULL,
                                  `parametersPost` longtext DEFAULT NULL,
                                  `cookies` longtext DEFAULT NULL,
                                  `serverVars` longtext DEFAULT NULL,
                                  `date` int(11) unsigned DEFAULT NULL,
                                  `count` bigint(20) unsigned DEFAULT NULL,
                                  PRIMARY KEY (`id`),
                                  KEY `uri` (`uri`),
                                  KEY `code` (`code`),
                                  KEY `date` (`date`),
                                  KEY `count` (`count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `http_error_log`
--

LOCK TABLES `http_error_log` WRITE;
/*!40000 ALTER TABLE `http_error_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `http_error_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importconfig_shares`
--

DROP TABLE IF EXISTS `importconfig_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importconfig_shares` (
                                       `importConfigId` int(11) NOT NULL,
                                       `sharedWithUserId` int(11) NOT NULL,
                                       PRIMARY KEY (`importConfigId`,`sharedWithUserId`),
                                       KEY `sharedWithUserId` (`sharedWithUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importconfig_shares`
--

LOCK TABLES `importconfig_shares` WRITE;
/*!40000 ALTER TABLE `importconfig_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `importconfig_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importconfigs`
--

DROP TABLE IF EXISTS `importconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importconfigs` (
                                 `id` int(11) NOT NULL AUTO_INCREMENT,
                                 `ownerId` int(11) DEFAULT NULL,
                                 `classId` varchar(50) DEFAULT NULL,
                                 `name` varchar(50) DEFAULT NULL,
                                 `config` longtext DEFAULT NULL,
                                 `description` longtext DEFAULT NULL,
                                 `creationDate` int(11) DEFAULT NULL,
                                 `modificationDate` int(11) DEFAULT NULL,
                                 `shareGlobally` tinyint(1) DEFAULT NULL,
                                 PRIMARY KEY (`id`),
                                 KEY `ownerId` (`ownerId`),
                                 KEY `classId` (`classId`),
                                 KEY `shareGlobally` (`shareGlobally`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importconfigs`
--

LOCK TABLES `importconfigs` WRITE;
/*!40000 ALTER TABLE `importconfigs` DISABLE KEYS */;
/*!40000 ALTER TABLE `importconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lock_keys`
--

DROP TABLE IF EXISTS `lock_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lock_keys` (
                             `key_id` varchar(64) NOT NULL,
                             `key_token` varchar(44) NOT NULL,
                             `key_expiration` int(10) unsigned NOT NULL,
                             PRIMARY KEY (`key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lock_keys`
--

LOCK TABLES `lock_keys` WRITE;
/*!40000 ALTER TABLE `lock_keys` DISABLE KEYS */;
INSERT INTO `lock_keys` VALUES
    ('65b8fc17a1cbbf3557066e114a07ecb3f5a15ce61423affe7a032548fb255afb','81Dy5gkaAcuKul7iqMWm5sPCXMGyxoy3PT/sNcVh0NI=',1664809803);
/*!40000 ALTER TABLE `lock_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
                                      `id` bigint(20) NOT NULL AUTO_INCREMENT,
                                      `body` longtext NOT NULL,
                                      `headers` longtext NOT NULL,
                                      `queue_name` varchar(190) NOT NULL,
                                      `created_at` datetime NOT NULL,
                                      `available_at` datetime NOT NULL,
                                      `delivered_at` datetime DEFAULT NULL,
                                      PRIMARY KEY (`id`),
                                      KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
                                      KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
                                      KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB AUTO_INCREMENT=195623 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration_versions` (
                                      `version` varchar(1024) COLLATE utf8mb3_unicode_ci NOT NULL,
                                      `executed_at` datetime DEFAULT NULL,
                                      `execution_time` int(11) DEFAULT NULL,
                                      PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008082752',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008091131',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008101817',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008132324',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201009095924',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201012154224',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201014101437',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201113143914',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201201084201',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210107103923',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210218142556',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210323082921',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210323110055',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210324152821',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210324152822',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210330132354',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210408153226',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210412112812',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210428145320',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210430124911',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210505093841',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210531125102',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210608094532',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210616114744',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210624085031',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210630062445',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210702102100',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210706090823',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210901130000',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210928135248',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211016084043',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211018104331',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211028134037',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211028155535',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211103055110',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211117173000','2022-08-09 09:47:52',59),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211209131141','2022-08-09 09:47:52',440),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211221152344','2022-08-09 09:47:52',31),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220119082511','2022-08-09 09:47:53',50),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220120121803','2022-08-09 09:47:53',138),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220120162621','2022-08-09 09:47:53',560),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220201132131','2022-08-09 09:47:53',1),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220214110000','2022-08-09 09:47:53',435),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220317125711','2022-08-09 09:47:54',367),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220318101020','2022-08-09 09:47:54',0),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220402104849','2022-08-09 09:47:54',24),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220411172543','2022-08-09 09:47:54',2),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220419120333','2022-08-09 09:47:54',430),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220425082914','2022-08-09 09:47:55',14),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220502104200','2022-08-09 09:47:55',22),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220506103100','2022-08-09 09:47:55',364),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220511085800','2022-08-09 09:47:55',494),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220718162200','2022-08-09 09:47:55',13),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220725154615','2022-08-09 09:47:55',359),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version22020614115124','2022-08-09 09:47:56',387),
                                     ('Pimcore\\Bundle\\DataHubBundle\\Migrations\\PimcoreX\\Version20210305134111',NULL,NULL),
                                     ('Pimcore\\Bundle\\DataHubBundle\\Migrations\\PimcoreX\\Version20211108160248','2022-08-09 11:19:48',43),
                                     ('Pimcore\\Bundle\\DataImporterBundle\\Migrations\\Version20210305134111','2022-08-09 09:47:56',3),
                                     ('Pimcore\\Bundle\\DataImporterBundle\\Migrations\\Version20211110174732','2022-08-09 09:47:56',404),
                                     ('Pimcore\\Bundle\\DataImporterBundle\\Migrations\\Version20211201173215','2022-08-09 09:47:57',462),
                                     ('Pimcore\\Bundle\\DataImporterBundle\\Migrations\\Version20220304130000','2022-08-09 09:47:57',406);
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `type` varchar(255) DEFAULT NULL,
                         `cid` int(11) DEFAULT NULL,
                         `ctype` enum('asset','document','object') DEFAULT NULL,
                         `date` int(11) DEFAULT NULL,
                         `user` int(11) DEFAULT NULL,
                         `title` varchar(255) DEFAULT NULL,
                         `description` longtext DEFAULT NULL,
                         PRIMARY KEY (`id`),
                         KEY `cid_ctype` (`cid`,`ctype`),
                         KEY `date` (`date`),
                         KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes_data`
--

DROP TABLE IF EXISTS `notes_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes_data` (
                              `id` int(11) NOT NULL,
                              `name` varchar(255) NOT NULL,
                              `type` enum('text','date','document','asset','object','bool') DEFAULT NULL,
                              `data` text DEFAULT NULL,
                              PRIMARY KEY (`id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes_data`
--

LOCK TABLES `notes_data` WRITE;
/*!40000 ALTER TABLE `notes_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
                                 `id` int(11) NOT NULL AUTO_INCREMENT,
                                 `type` varchar(20) NOT NULL DEFAULT 'info',
                                 `title` varchar(250) NOT NULL DEFAULT '',
                                 `message` text NOT NULL,
                                 `sender` int(11) DEFAULT NULL,
                                 `recipient` int(11) NOT NULL,
                                 `read` tinyint(1) NOT NULL DEFAULT 0,
                                 `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
                                 `modificationDate` timestamp NULL DEFAULT NULL,
                                 `linkedElementType` enum('document','asset','object') DEFAULT NULL,
                                 `linkedElement` int(11) DEFAULT NULL,
                                 PRIMARY KEY (`id`),
                                 KEY `recipient` (`recipient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_url_slugs`
--

DROP TABLE IF EXISTS `object_url_slugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_url_slugs` (
                                    `objectId` int(11) unsigned NOT NULL DEFAULT 0,
                                    `classId` varchar(50) NOT NULL DEFAULT '0',
                                    `fieldname` varchar(70) NOT NULL DEFAULT '0',
                                    `index` int(11) unsigned NOT NULL DEFAULT 0,
                                    `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
                                    `ownername` varchar(70) NOT NULL DEFAULT '',
                                    `position` varchar(70) NOT NULL DEFAULT '0',
                                    `slug` varchar(765) NOT NULL,
                                    `siteId` int(11) NOT NULL DEFAULT 0,
                                    PRIMARY KEY (`slug`,`siteId`),
                                    KEY `index` (`index`),
                                    KEY `objectId` (`objectId`),
                                    KEY `classId` (`classId`),
                                    KEY `fieldname` (`fieldname`),
                                    KEY `position` (`position`),
                                    KEY `ownertype` (`ownertype`),
                                    KEY `ownername` (`ownername`),
                                    KEY `slug` (`slug`),
                                    KEY `siteId` (`siteId`),
                                    KEY `fieldname_ownertype_position_objectId` (`fieldname`,`ownertype`,`position`,`objectId`),
                                    CONSTRAINT `fk_object_url_slugs__objectId` FOREIGN KEY (`objectId`) REFERENCES `objects` (`o_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_url_slugs`
--

LOCK TABLES `object_url_slugs` WRITE;
/*!40000 ALTER TABLE `object_url_slugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_url_slugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objects`
--

DROP TABLE IF EXISTS `objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objects` (
                           `o_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                           `o_parentId` int(11) unsigned DEFAULT NULL,
                           `o_type` enum('object','folder','variant') DEFAULT NULL,
                           `o_key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
                           `o_path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                           `o_index` int(11) unsigned DEFAULT 0,
                           `o_published` tinyint(1) unsigned DEFAULT 1,
                           `o_creationDate` int(11) unsigned DEFAULT NULL,
                           `o_modificationDate` int(11) unsigned DEFAULT NULL,
                           `o_userOwner` int(11) unsigned DEFAULT NULL,
                           `o_userModification` int(11) unsigned DEFAULT NULL,
                           `o_classId` varchar(50) DEFAULT NULL,
                           `o_className` varchar(255) DEFAULT NULL,
                           `o_childrenSortBy` enum('key','index') DEFAULT NULL,
                           `o_childrenSortOrder` enum('ASC','DESC') DEFAULT NULL,
                           `o_versionCount` int(10) unsigned NOT NULL DEFAULT 0,
                           PRIMARY KEY (`o_id`),
                           UNIQUE KEY `fullpath` (`o_path`,`o_key`),
                           KEY `key` (`o_key`),
                           KEY `index` (`o_index`),
                           KEY `published` (`o_published`),
                           KEY `parentId` (`o_parentId`),
                           KEY `o_modificationDate` (`o_modificationDate`),
                           KEY `o_classId` (`o_classId`),
                           KEY `type_path_classId` (`o_type`,`o_path`,`o_classId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objects`
--

LOCK TABLES `objects` WRITE;
/*!40000 ALTER TABLE `objects` DISABLE KEYS */;
INSERT INTO `objects` VALUES
    (1,0,'folder','','/',999999,1,1657535401,1657535401,1,1,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_datahub_workspaces_asset`
--

DROP TABLE IF EXISTS `plugin_datahub_workspaces_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin_datahub_workspaces_asset` (
                                                   `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                                   `cpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                                                   `configuration` varchar(80) NOT NULL DEFAULT '0',
                                                   `create` tinyint(1) unsigned DEFAULT 0,
                                                   `read` tinyint(1) unsigned DEFAULT 0,
                                                   `update` tinyint(1) unsigned DEFAULT 0,
                                                   `delete` tinyint(1) unsigned DEFAULT 0,
                                                   PRIMARY KEY (`cid`,`configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_datahub_workspaces_asset`
--

LOCK TABLES `plugin_datahub_workspaces_asset` WRITE;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_datahub_workspaces_document`
--

DROP TABLE IF EXISTS `plugin_datahub_workspaces_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin_datahub_workspaces_document` (
                                                      `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                                      `cpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                                                      `configuration` varchar(80) NOT NULL DEFAULT '0',
                                                      `create` tinyint(1) unsigned DEFAULT 0,
                                                      `read` tinyint(1) unsigned DEFAULT 0,
                                                      `update` tinyint(1) unsigned DEFAULT 0,
                                                      `delete` tinyint(1) unsigned DEFAULT 0,
                                                      PRIMARY KEY (`cid`,`configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_datahub_workspaces_document`
--

LOCK TABLES `plugin_datahub_workspaces_document` WRITE;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_datahub_workspaces_object`
--

DROP TABLE IF EXISTS `plugin_datahub_workspaces_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin_datahub_workspaces_object` (
                                                    `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                                    `cpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                                                    `configuration` varchar(80) NOT NULL DEFAULT '0',
                                                    `create` tinyint(1) unsigned DEFAULT 0,
                                                    `read` tinyint(1) unsigned DEFAULT 0,
                                                    `update` tinyint(1) unsigned DEFAULT 0,
                                                    `delete` tinyint(1) unsigned DEFAULT 0,
                                                    PRIMARY KEY (`cid`,`configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_datahub_workspaces_object`
--

LOCK TABLES `plugin_datahub_workspaces_object` WRITE;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `properties` (
                              `cid` int(11) unsigned NOT NULL DEFAULT 0,
                              `ctype` enum('document','asset','object') NOT NULL DEFAULT 'document',
                              `cpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                              `name` varchar(190) NOT NULL DEFAULT '',
                              `type` enum('text','document','asset','object','bool','select') DEFAULT NULL,
                              `data` text DEFAULT NULL,
                              `inheritable` tinyint(1) unsigned DEFAULT 1,
                              PRIMARY KEY (`cid`,`ctype`,`name`),
                              KEY `getall` (`cpath`,`ctype`,`inheritable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties`
--

LOCK TABLES `properties` WRITE;
/*!40000 ALTER TABLE `properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quantityvalue_units`
--

DROP TABLE IF EXISTS `quantityvalue_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quantityvalue_units` (
                                       `id` varchar(50) NOT NULL,
                                       `group` varchar(50) DEFAULT NULL,
                                       `abbreviation` varchar(20) DEFAULT NULL,
                                       `longname` varchar(250) DEFAULT NULL,
                                       `baseunit` varchar(50) DEFAULT NULL,
                                       `factor` double DEFAULT NULL,
                                       `conversionOffset` double DEFAULT NULL,
                                       `reference` varchar(50) DEFAULT NULL,
                                       `converter` varchar(255) DEFAULT NULL,
                                       PRIMARY KEY (`id`),
                                       KEY `fk_baseunit` (`baseunit`),
                                       CONSTRAINT `fk_baseunit` FOREIGN KEY (`baseunit`) REFERENCES `quantityvalue_units` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quantityvalue_units`
--

LOCK TABLES `quantityvalue_units` WRITE;
/*!40000 ALTER TABLE `quantityvalue_units` DISABLE KEYS */;
/*!40000 ALTER TABLE `quantityvalue_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recyclebin`
--

DROP TABLE IF EXISTS `recyclebin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recyclebin` (
                              `id` int(11) NOT NULL AUTO_INCREMENT,
                              `type` varchar(20) DEFAULT NULL,
                              `subtype` varchar(20) DEFAULT NULL,
                              `path` varchar(765) DEFAULT NULL,
                              `amount` int(3) DEFAULT NULL,
                              `date` int(11) unsigned DEFAULT NULL,
                              `deletedby` varchar(50) DEFAULT NULL,
                              PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recyclebin`
--

LOCK TABLES `recyclebin` WRITE;
/*!40000 ALTER TABLE `recyclebin` DISABLE KEYS */;
/*!40000 ALTER TABLE `recyclebin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redirects`
--

DROP TABLE IF EXISTS `redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redirects` (
                             `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                             `type` enum('entire_uri','path_query','path','auto_create') NOT NULL,
                             `source` varchar(255) DEFAULT NULL,
                             `sourceSite` int(11) DEFAULT NULL,
                             `target` varchar(255) DEFAULT NULL,
                             `targetSite` int(11) DEFAULT NULL,
                             `statusCode` varchar(3) DEFAULT NULL,
                             `priority` int(2) DEFAULT 0,
                             `regex` tinyint(1) DEFAULT NULL,
                             `passThroughParameters` tinyint(1) DEFAULT NULL,
                             `active` tinyint(1) DEFAULT NULL,
                             `expiry` int(11) unsigned DEFAULT NULL,
                             `creationDate` int(11) unsigned DEFAULT 0,
                             `modificationDate` int(11) unsigned DEFAULT 0,
                             `userOwner` int(11) unsigned DEFAULT NULL,
                             `userModification` int(11) unsigned DEFAULT NULL,
                             PRIMARY KEY (`id`),
                             KEY `priority` (`priority`),
                             KEY `routing_lookup` (`active`,`regex`,`sourceSite`,`source`,`type`,`expiry`,`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redirects`
--

LOCK TABLES `redirects` WRITE;
/*!40000 ALTER TABLE `redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_tasks`
--

DROP TABLE IF EXISTS `schedule_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_tasks` (
                                  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                  `cid` int(11) unsigned DEFAULT NULL,
                                  `ctype` enum('document','asset','object') DEFAULT NULL,
                                  `date` int(11) unsigned DEFAULT NULL,
                                  `action` enum('publish','unpublish','delete','publish-version') DEFAULT NULL,
                                  `version` bigint(20) unsigned DEFAULT NULL,
                                  `active` tinyint(1) unsigned DEFAULT 0,
                                  `userId` int(11) unsigned DEFAULT NULL,
                                  PRIMARY KEY (`id`),
                                  KEY `cid` (`cid`),
                                  KEY `ctype` (`ctype`),
                                  KEY `active` (`active`),
                                  KEY `version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_tasks`
--

LOCK TABLES `schedule_tasks` WRITE;
/*!40000 ALTER TABLE `schedule_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_backend_data`
--

DROP TABLE IF EXISTS `search_backend_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_backend_data` (
                                       `id` int(11) NOT NULL,
                                       `fullpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                                       `maintype` varchar(8) NOT NULL DEFAULT '',
                                       `type` varchar(20) DEFAULT NULL,
                                       `subtype` varchar(190) DEFAULT NULL,
                                       `published` tinyint(1) unsigned DEFAULT NULL,
                                       `creationDate` int(11) unsigned DEFAULT NULL,
                                       `modificationDate` int(11) unsigned DEFAULT NULL,
                                       `userOwner` int(11) DEFAULT NULL,
                                       `userModification` int(11) DEFAULT NULL,
                                       `data` longtext DEFAULT NULL,
                                       `properties` text DEFAULT NULL,
                                       `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
                                       `index` int(11) unsigned DEFAULT 0,
                                       PRIMARY KEY (`id`,`maintype`),
                                       KEY `fullpath` (`fullpath`),
                                       KEY `maintype` (`maintype`),
                                       KEY `type` (`type`),
                                       KEY `subtype` (`subtype`),
                                       KEY `published` (`published`),
                                       KEY `key` (`key`),
                                       KEY `index` (`index`),
                                       FULLTEXT KEY `fulltext` (`data`,`properties`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_backend_data`
--

LOCK TABLES `search_backend_data` WRITE;
/*!40000 ALTER TABLE `search_backend_data` DISABLE KEYS */;
INSERT INTO `search_backend_data` VALUES
                                      (1,'/','asset','folder','folder',1,1657535401,1657535401,1,1,'ID: 1  \nPath: /  \n','','',NULL),
                                      (1,'/','document','page','page',1,1657535401,1657535401,1,1,'ID: 1  \nPath: /  \n','','',999999),
                                      (1,'/','object','folder','folder',1,1657535401,1657535401,1,1,'ID: 1  \nPath: /  \n','','',NULL);
/*!40000 ALTER TABLE `search_backend_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings_store`
--

DROP TABLE IF EXISTS `settings_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings_store` (
                                  `id` varchar(190) NOT NULL DEFAULT '',
                                  `scope` varchar(190) NOT NULL DEFAULT '',
                                  `data` longtext DEFAULT NULL,
                                  `type` enum('bool','int','float','string') NOT NULL DEFAULT 'string',
                                  PRIMARY KEY (`id`,`scope`),
                                  KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_store`
--

LOCK TABLES `settings_store` WRITE;
/*!40000 ALTER TABLE `settings_store` DISABLE KEYS */;
INSERT INTO `settings_store` VALUES
                                 ('BUNDLE_INSTALLED__Pimcore\\Bundle\\DataHubBundle\\PimcoreDataHubBundle','pimcore','1','bool'),
                                 ('BUNDLE_INSTALLED__Pimcore\\Bundle\\DataImporterBundle\\PimcoreDataImporterBundle','pimcore','1','bool');
/*!40000 ALTER TABLE `settings_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
                         `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                         `mainDomain` varchar(255) DEFAULT NULL,
                         `domains` text DEFAULT NULL,
                         `rootId` int(11) unsigned DEFAULT NULL,
                         `errorDocument` varchar(255) DEFAULT NULL,
                         `localizedErrorDocuments` text DEFAULT NULL,
                         `redirectToMainDomain` tinyint(1) DEFAULT NULL,
                         `creationDate` int(11) unsigned DEFAULT 0,
                         `modificationDate` int(11) unsigned DEFAULT 0,
                         PRIMARY KEY (`id`),
                         UNIQUE KEY `rootId` (`rootId`),
                         CONSTRAINT `fk_sites_documents` FOREIGN KEY (`rootId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
                        `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                        `parentId` int(10) unsigned DEFAULT NULL,
                        `idPath` varchar(190) DEFAULT NULL,
                        `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                        PRIMARY KEY (`id`),
                        UNIQUE KEY `idPath_name` (`idPath`,`name`),
                        KEY `idpath` (`idPath`),
                        KEY `parentid` (`parentId`),
                        KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags_assignment`
--

DROP TABLE IF EXISTS `tags_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags_assignment` (
                                   `tagid` int(10) unsigned NOT NULL DEFAULT 0,
                                   `cid` int(10) NOT NULL DEFAULT 0,
                                   `ctype` enum('document','asset','object') NOT NULL,
                                   PRIMARY KEY (`tagid`,`cid`,`ctype`),
                                   KEY `ctype` (`ctype`),
                                   KEY `ctype_cid` (`cid`,`ctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags_assignment`
--

LOCK TABLES `tags_assignment` WRITE;
/*!40000 ALTER TABLE `tags_assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `targeting_rules`
--

DROP TABLE IF EXISTS `targeting_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targeting_rules` (
                                   `id` int(11) NOT NULL AUTO_INCREMENT,
                                   `name` varchar(255) NOT NULL DEFAULT '',
                                   `description` text DEFAULT NULL,
                                   `scope` varchar(50) DEFAULT NULL,
                                   `active` tinyint(1) DEFAULT NULL,
                                   `prio` smallint(5) unsigned NOT NULL DEFAULT 0,
                                   `conditions` longtext DEFAULT NULL,
                                   `actions` longtext DEFAULT NULL,
                                   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `targeting_rules`
--

LOCK TABLES `targeting_rules` WRITE;
/*!40000 ALTER TABLE `targeting_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `targeting_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `targeting_storage`
--

DROP TABLE IF EXISTS `targeting_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targeting_storage` (
                                     `visitorId` varchar(100) NOT NULL,
                                     `scope` varchar(50) NOT NULL,
                                     `name` varchar(100) NOT NULL,
                                     `value` text DEFAULT NULL,
                                     `creationDate` datetime DEFAULT NULL,
                                     `modificationDate` datetime DEFAULT NULL,
                                     PRIMARY KEY (`visitorId`,`scope`,`name`),
                                     KEY `targeting_storage_scope_index` (`scope`),
                                     KEY `targeting_storage_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `targeting_storage`
--

LOCK TABLES `targeting_storage` WRITE;
/*!40000 ALTER TABLE `targeting_storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `targeting_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `targeting_target_groups`
--

DROP TABLE IF EXISTS `targeting_target_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targeting_target_groups` (
                                           `id` int(11) NOT NULL AUTO_INCREMENT,
                                           `name` varchar(255) NOT NULL DEFAULT '',
                                           `description` text DEFAULT NULL,
                                           `threshold` int(11) DEFAULT NULL,
                                           `active` tinyint(1) DEFAULT NULL,
                                           PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `targeting_target_groups`
--

LOCK TABLES `targeting_target_groups` WRITE;
/*!40000 ALTER TABLE `targeting_target_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `targeting_target_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp_store`
--

DROP TABLE IF EXISTS `tmp_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_store` (
                             `id` varchar(190) NOT NULL DEFAULT '',
                             `tag` varchar(190) DEFAULT NULL,
                             `data` longtext DEFAULT NULL,
                             `serialized` tinyint(2) NOT NULL DEFAULT 0,
                             `date` int(11) unsigned DEFAULT NULL,
                             `expiryDate` int(11) unsigned DEFAULT NULL,
                             PRIMARY KEY (`id`),
                             KEY `tag` (`tag`),
                             KEY `date` (`date`),
                             KEY `expiryDate` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp_store`
--

LOCK TABLES `tmp_store` WRITE;
/*!40000 ALTER TABLE `tmp_store` DISABLE KEYS */;
INSERT INTO `tmp_store` VALUES
                            ('log-usagelog.log',NULL,'1663884002',0,1663884002,1664488802),
                            ('maintenance.pid',NULL,'1664434802',0,1664434802,1665039602);
/*!40000 ALTER TABLE `tmp_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations_admin`
--

DROP TABLE IF EXISTS `translations_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations_admin` (
                                      `key` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
                                      `type` varchar(10) DEFAULT NULL,
                                      `language` varchar(10) NOT NULL DEFAULT '',
                                      `text` text DEFAULT NULL,
                                      `creationDate` int(11) unsigned DEFAULT NULL,
                                      `modificationDate` int(11) unsigned DEFAULT NULL,
                                      `userOwner` int(11) unsigned DEFAULT NULL,
                                      `userModification` int(11) unsigned DEFAULT NULL,
                                      PRIMARY KEY (`key`,`language`),
                                      KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations_admin`
--

LOCK TABLES `translations_admin` WRITE;
/*!40000 ALTER TABLE `translations_admin` DISABLE KEYS */;
INSERT INTO `translations_admin` VALUES
                                     ('API key does not satisfy the minimum length of 16 characters','simple','cs','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','de','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','en','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','es','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','fa','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','fr','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','hu','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','it','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','ja','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','nl','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','pl','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','pt','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','pt_BR','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','ru','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','sk','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','sv','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','sv_FI','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','th','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','tr','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','uk','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','zh_Hans','',1659950773,1659950773,NULL,NULL),
                                     ('Alt','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('The configuration was modified during editing, please reload the configuration and make your changes again','simple','en','',1659951986,1659951986,NULL,NULL),
                                     ('clear_fullpage_cache','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('delete_message_advanced','simple','en','',1664796920,1664796920,NULL,NULL),
                                     ('down','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('efwe','simple','cs','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','de','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','en','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','es','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','fa','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','fr','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','hu','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','it','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','ja','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','nl','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','pl','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','pt','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','pt_BR','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','ru','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','sk','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','sv','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','sv_FI','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','th','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','tr','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','uk','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','zh_Hans','efwe',1658495671,1658495671,NULL,NULL),
                                     ('global','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('keybinding_tagManager','simple','cs','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','de','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','en','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','es','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','fa','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','fr','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','hu','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','it','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','ja','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','nl','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','pl','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','pt','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','pt_BR','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','ru','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','sk','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','sv','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','sv_FI','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','th','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','tr','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','uk','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','zh_Hans','',1658738505,1658738505,NULL,NULL),
                                     ('login','simple','en','',1657535487,1657535487,NULL,NULL),
                                     ('login','simple','nl','',1657535487,1657535487,NULL,NULL),
                                     ('multiline','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('up','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','zh_Hans','',1658738504,1658738504,NULL,NULL);
/*!40000 ALTER TABLE `translations_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations_messages`
--

DROP TABLE IF EXISTS `translations_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations_messages` (
                                         `key` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
                                         `type` varchar(10) DEFAULT NULL,
                                         `language` varchar(10) NOT NULL DEFAULT '',
                                         `text` text DEFAULT NULL,
                                         `creationDate` int(11) unsigned DEFAULT NULL,
                                         `modificationDate` int(11) unsigned DEFAULT NULL,
                                         `userOwner` int(11) unsigned DEFAULT NULL,
                                         `userModification` int(11) unsigned DEFAULT NULL,
                                         PRIMARY KEY (`key`,`language`),
                                         KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations_messages`
--

LOCK TABLES `translations_messages` WRITE;
/*!40000 ALTER TABLE `translations_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `translations_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tree_locks`
--

DROP TABLE IF EXISTS `tree_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tree_locks` (
                              `id` int(11) NOT NULL DEFAULT 0,
                              `type` enum('asset','document','object') NOT NULL DEFAULT 'asset',
                              `locked` enum('self','propagate') DEFAULT NULL,
                              PRIMARY KEY (`id`,`type`),
                              KEY `type` (`type`),
                              KEY `locked` (`locked`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tree_locks`
--

LOCK TABLES `tree_locks` WRITE;
/*!40000 ALTER TABLE `tree_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tree_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
                         `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                         `parentId` int(11) unsigned DEFAULT NULL,
                         `type` enum('user','userfolder','role','rolefolder') NOT NULL DEFAULT 'user',
                         `name` varchar(50) DEFAULT NULL,
                         `password` varchar(190) DEFAULT NULL,
                         `firstname` varchar(255) DEFAULT NULL,
                         `lastname` varchar(255) DEFAULT NULL,
                         `email` varchar(255) DEFAULT NULL,
                         `language` varchar(10) DEFAULT NULL,
                         `contentLanguages` longtext DEFAULT NULL,
                         `admin` tinyint(1) unsigned DEFAULT 0,
                         `active` tinyint(1) unsigned DEFAULT 1,
                         `permissions` text DEFAULT NULL,
                         `roles` varchar(1000) DEFAULT NULL,
                         `welcomescreen` tinyint(1) DEFAULT NULL,
                         `closeWarning` tinyint(1) DEFAULT NULL,
                         `memorizeTabs` tinyint(1) DEFAULT NULL,
                         `allowDirtyClose` tinyint(1) unsigned DEFAULT 1,
                         `docTypes` text DEFAULT NULL,
                         `classes` text DEFAULT NULL,
                         `twoFactorAuthentication` varchar(255) DEFAULT NULL,
                         `activePerspective` varchar(255) DEFAULT NULL,
                         `perspectives` longtext DEFAULT NULL,
                         `websiteTranslationLanguagesEdit` longtext DEFAULT NULL,
                         `websiteTranslationLanguagesView` longtext DEFAULT NULL,
                         `lastLogin` int(11) unsigned DEFAULT NULL,
                         `keyBindings` text DEFAULT NULL,
                         PRIMARY KEY (`id`),
                         UNIQUE KEY `type_name` (`type`,`name`),
                         KEY `parentId` (`parentId`),
                         KEY `name` (`name`),
                         KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
                        (0,0,'user','system',NULL,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
                        (2,0,'user','admin','$2y$10$0WXFQQqiNIwFOLixmcPadOrkjp0Sa2xV6.WWNzM8dVUhAzybMxACG','','','','en','en',1,1,'admin_translations,application_logging,assets,asset_metadata,classes,clear_cache,clear_fullpage_cache,clear_temp_files,dashboards,documents,document_types,emails,gdpr_data_extractor,glossary,http_errors,notes_events,notifications,notifications_send,objects,objects_sort_method,plugins,predefined_properties,recyclebin,redirects,reports,reports_config,robots.txt,routes,seemode,seo_document_editor,share_configurations,sites,system_settings,tags_assignment,tags_configuration,tags_search,targeting,thumbnails,translations,users,web2print_settings,website_settings,workflow_details','',0,1,1,0,'','','{\"required\":false,\"enabled\":false,\"secret\":\"\",\"type\":\"\"}',NULL,'','','',1664795635,'[{\"action\":\"save\",\"key\":83,\"ctrl\":true},{\"action\":\"publish\",\"key\":80,\"ctrl\":true,\"shift\":true},{\"action\":\"unpublish\",\"key\":85,\"ctrl\":true,\"shift\":true},{\"action\":\"rename\",\"key\":82,\"alt\":true,\"shift\":true},{\"action\":\"refresh\",\"key\":116},{\"action\":\"openDocument\",\"key\":68,\"ctrl\":true,\"shift\":true},{\"action\":\"openAsset\",\"key\":65,\"ctrl\":true,\"shift\":true},{\"action\":\"openObject\",\"key\":79,\"ctrl\":true,\"shift\":true},{\"action\":\"openClassEditor\",\"key\":67,\"ctrl\":true,\"shift\":true},{\"action\":\"openInTree\",\"key\":76,\"ctrl\":true,\"shift\":true},{\"action\":\"showMetaInfo\",\"key\":73,\"alt\":true},{\"action\":\"searchDocument\",\"key\":87,\"alt\":true},{\"action\":\"searchAsset\",\"key\":65,\"alt\":true},{\"action\":\"searchObject\",\"key\":79,\"alt\":true},{\"action\":\"showElementHistory\",\"key\":72,\"alt\":true},{\"action\":\"closeAllTabs\",\"key\":84,\"alt\":true},{\"action\":\"searchAndReplaceAssignments\",\"key\":83,\"alt\":true},{\"action\":\"glossary\",\"key\":71,\"shift\":true,\"alt\":true},{\"action\":\"redirects\",\"key\":82,\"ctrl\":false,\"alt\":true},{\"action\":\"sharedTranslations\",\"key\":84,\"ctrl\":true,\"alt\":true},{\"action\":\"recycleBin\",\"key\":82,\"ctrl\":true,\"alt\":true},{\"action\":\"notesEvents\",\"key\":78,\"ctrl\":true,\"alt\":true},{\"action\":\"applicationLogger\",\"key\":76,\"ctrl\":true,\"alt\":true},{\"action\":\"reports\",\"key\":77,\"ctrl\":true,\"alt\":true},{\"action\":\"tagManager\",\"key\":72,\"ctrl\":true,\"alt\":true},{\"action\":\"seoDocumentEditor\",\"key\":83,\"ctrl\":true,\"alt\":true},{\"action\":\"robots\",\"key\":74,\"ctrl\":true,\"alt\":true},{\"action\":\"httpErrorLog\",\"key\":79,\"ctrl\":true,\"alt\":true},{\"action\":\"customReports\",\"key\":67,\"ctrl\":true,\"alt\":true},{\"action\":\"tagConfiguration\",\"key\":78,\"ctrl\":true,\"alt\":true},{\"action\":\"users\",\"key\":85,\"ctrl\":true,\"alt\":true},{\"action\":\"roles\",\"key\":80,\"ctrl\":true,\"alt\":true},{\"action\":\"clearAllCaches\",\"key\":81,\"ctrl\":false,\"alt\":true},{\"action\":\"clearDataCache\",\"key\":67,\"ctrl\":false,\"alt\":true},{\"action\":\"quickSearch\",\"key\":70,\"ctrl\":true,\"shift\":true}]'),
                        (3,0,'userfolder','SSO',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
                        (4,3,'userfolder','Youwe-OneLogin',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
                        (5,NULL,'role','OneLogin',NULL,NULL,NULL,NULL,NULL,NULL,0,1,'',NULL,NULL,NULL,NULL,1,'','',NULL,NULL,'','','',NULL,NULL),
                        (6,4,'user','j.mattar@youweagency.com-onelogin','968d5297dc517bfb4badf2be55ff02f57efb878b5dc8a12d82150b8a035eb7f539c9c458807800646705011c33683219c52b2e5e866440e4ad81f0522d66650a042f4fbe72ae21579f33bdb9a136ada0e77260f18e0531cc9ea81c240318f8','Jean','Mattar','j.mattar@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',0,NULL),
                        (7,4,'user','j.groefsema@youweagency.com-onelogin','b2cec2a962088be5ba5c983d02438ba1db747b2a1734568c25763bb60a08562900671721ea648bf757136d9821326250d38a4015a24ac76baa458aa65ce4614204950c701996022e2ee69b31958bf52c9f965953727b731450e9157156850d','Jeffrey','Groefsema','j.groefsema@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',0,NULL),
                        (8,4,'user','m.mijailovic@youweagency.com-onelogin','557a4fa089e9a91039bc6a907ae29392c645ce899779a1bf4a97c10c02fcfcc7c8ece3f3363b9213985fb25922260e72e9f7ae5fe8cc0355a4e3139e84da7c473ec4572a81090ce766f8c3bc78135078a717b8e5e7aa36c655cb3cebdfa85c','Marko','Mijailovic','m.mijailovic@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',0,NULL),
                        (10,4,'user','k.ovsiannikova@youweagency.com-onelogin','cd1803398b52318e14d5b38f5726155434b34c5b64b993150d54dfa41ce8fd50a50550df1cfb60da77aba589c31cae07e2fd54aa84d4aa82d30c73097c5ac777865e00d3ceb50e4fbb63f81514ef317f4535fe96be2bc88d85282bd90cecbd','Kseniia','Ovsiannikova','k.ovsiannikova@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',NULL,NULL),
                        (11,4,'user','b.memic@youweagency.com-onelogin','d5f9ecf308f6bde20fda1808c9c01a23cb6642921a869e8f6735321b7944a658eac5ed433d2d53ec7e23700ad31016087726086bc07c83add5de46a418e97188eb04188dc660dccb449c9b024f13a2e51b3380b8ceb13f7dfe9cea9825408c','Bojan','Memic','b.memic@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_permission_definitions`
--

DROP TABLE IF EXISTS `users_permission_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_permission_definitions` (
                                                `key` varchar(50) NOT NULL DEFAULT '',
                                                `category` varchar(50) NOT NULL DEFAULT '',
                                                PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_permission_definitions`
--

LOCK TABLES `users_permission_definitions` WRITE;
/*!40000 ALTER TABLE `users_permission_definitions` DISABLE KEYS */;
INSERT INTO `users_permission_definitions` VALUES
                                               ('admin_translations',''),
                                               ('application_logging',''),
                                               ('assets',''),
                                               ('asset_metadata',''),
                                               ('classes',''),
                                               ('clear_cache',''),
                                               ('clear_fullpage_cache',''),
                                               ('clear_temp_files',''),
                                               ('dashboards',''),
                                               ('documents',''),
                                               ('document_types',''),
                                               ('emails',''),
                                               ('gdpr_data_extractor',''),
                                               ('glossary',''),
                                               ('http_errors',''),
                                               ('notes_events',''),
                                               ('notifications',''),
                                               ('notifications_send',''),
                                               ('objects',''),
                                               ('objects_sort_method',''),
                                               ('plugins',''),
                                               ('plugin_datahub_adapter_dataImporterDataObject','Datahub'),
                                               ('plugin_datahub_adapter_graphql','Datahub'),
                                               ('plugin_datahub_admin','Datahub'),
                                               ('plugin_datahub_config','Datahub'),
                                               ('predefined_properties',''),
                                               ('recyclebin',''),
                                               ('redirects',''),
                                               ('reports',''),
                                               ('reports_config',''),
                                               ('robots.txt',''),
                                               ('routes',''),
                                               ('seemode',''),
                                               ('seo_document_editor',''),
                                               ('share_configurations',''),
                                               ('sites',''),
                                               ('system_settings',''),
                                               ('tags_assignment',''),
                                               ('tags_configuration',''),
                                               ('tags_search',''),
                                               ('targeting',''),
                                               ('thumbnails',''),
                                               ('translations',''),
                                               ('users',''),
                                               ('web2print_settings',''),
                                               ('website_settings',''),
                                               ('workflow_details','');
/*!40000 ALTER TABLE `users_permission_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_asset`
--

DROP TABLE IF EXISTS `users_workspaces_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_workspaces_asset` (
                                          `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                          `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                                          `userId` int(11) unsigned NOT NULL DEFAULT 0,
                                          `list` tinyint(1) DEFAULT 0,
                                          `view` tinyint(1) DEFAULT 0,
                                          `publish` tinyint(1) DEFAULT 0,
                                          `delete` tinyint(1) DEFAULT 0,
                                          `rename` tinyint(1) DEFAULT 0,
                                          `create` tinyint(1) DEFAULT 0,
                                          `settings` tinyint(1) DEFAULT 0,
                                          `versions` tinyint(1) DEFAULT 0,
                                          `properties` tinyint(1) DEFAULT 0,
                                          PRIMARY KEY (`cid`,`userId`),
                                          UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
                                          KEY `userId` (`userId`),
                                          CONSTRAINT `fk_users_workspaces_asset_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
                                          CONSTRAINT `fk_users_workspaces_asset_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_asset`
--

LOCK TABLES `users_workspaces_asset` WRITE;
/*!40000 ALTER TABLE `users_workspaces_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_document`
--

DROP TABLE IF EXISTS `users_workspaces_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_workspaces_document` (
                                             `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                             `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                                             `userId` int(11) unsigned NOT NULL DEFAULT 0,
                                             `list` tinyint(1) unsigned DEFAULT 0,
                                             `view` tinyint(1) unsigned DEFAULT 0,
                                             `save` tinyint(1) unsigned DEFAULT 0,
                                             `publish` tinyint(1) unsigned DEFAULT 0,
                                             `unpublish` tinyint(1) unsigned DEFAULT 0,
                                             `delete` tinyint(1) unsigned DEFAULT 0,
                                             `rename` tinyint(1) unsigned DEFAULT 0,
                                             `create` tinyint(1) unsigned DEFAULT 0,
                                             `settings` tinyint(1) unsigned DEFAULT 0,
                                             `versions` tinyint(1) unsigned DEFAULT 0,
                                             `properties` tinyint(1) unsigned DEFAULT 0,
                                             PRIMARY KEY (`cid`,`userId`),
                                             UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
                                             KEY `userId` (`userId`),
                                             CONSTRAINT `fk_users_workspaces_document_documents` FOREIGN KEY (`cid`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
                                             CONSTRAINT `fk_users_workspaces_document_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_document`
--

LOCK TABLES `users_workspaces_document` WRITE;
/*!40000 ALTER TABLE `users_workspaces_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_object`
--

DROP TABLE IF EXISTS `users_workspaces_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_workspaces_object` (
                                           `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                           `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                                           `userId` int(11) unsigned NOT NULL DEFAULT 0,
                                           `list` tinyint(1) unsigned DEFAULT 0,
                                           `view` tinyint(1) unsigned DEFAULT 0,
                                           `save` tinyint(1) unsigned DEFAULT 0,
                                           `publish` tinyint(1) unsigned DEFAULT 0,
                                           `unpublish` tinyint(1) unsigned DEFAULT 0,
                                           `delete` tinyint(1) unsigned DEFAULT 0,
                                           `rename` tinyint(1) unsigned DEFAULT 0,
                                           `create` tinyint(1) unsigned DEFAULT 0,
                                           `settings` tinyint(1) unsigned DEFAULT 0,
                                           `versions` tinyint(1) unsigned DEFAULT 0,
                                           `properties` tinyint(1) unsigned DEFAULT 0,
                                           `lEdit` text DEFAULT NULL,
                                           `lView` text DEFAULT NULL,
                                           `layouts` text DEFAULT NULL,
                                           PRIMARY KEY (`cid`,`userId`),
                                           UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
                                           KEY `userId` (`userId`),
                                           CONSTRAINT `fk_users_workspaces_object_objects` FOREIGN KEY (`cid`) REFERENCES `objects` (`o_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
                                           CONSTRAINT `fk_users_workspaces_object_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_object`
--

LOCK TABLES `users_workspaces_object` WRITE;
/*!40000 ALTER TABLE `users_workspaces_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uuids`
--

DROP TABLE IF EXISTS `uuids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uuids` (
                         `uuid` char(36) NOT NULL,
                         `itemId` int(11) unsigned NOT NULL,
                         `type` varchar(25) NOT NULL,
                         `instanceIdentifier` varchar(50) NOT NULL,
                         PRIMARY KEY (`uuid`,`itemId`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uuids`
--

LOCK TABLES `uuids` WRITE;
/*!40000 ALTER TABLE `uuids` DISABLE KEYS */;
/*!40000 ALTER TABLE `uuids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `versions` (
                            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                            `cid` int(11) unsigned DEFAULT NULL,
                            `ctype` enum('document','asset','object') DEFAULT NULL,
                            `userId` int(11) unsigned DEFAULT NULL,
                            `note` text DEFAULT NULL,
                            `stackTrace` text DEFAULT NULL,
                            `date` int(11) unsigned DEFAULT NULL,
                            `public` tinyint(1) unsigned NOT NULL DEFAULT 0,
                            `serialized` tinyint(1) unsigned DEFAULT 0,
                            `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
                            `binaryFileHash` varchar(128) CHARACTER SET ascii DEFAULT NULL,
                            `binaryFileId` bigint(20) unsigned DEFAULT NULL,
                            `autoSave` tinyint(4) NOT NULL DEFAULT 0,
                            `storageType` varchar(5) NOT NULL,
                            PRIMARY KEY (`id`),
                            KEY `cid` (`cid`),
                            KEY `ctype_cid` (`ctype`,`cid`),
                            KEY `date` (`date`),
                            KEY `binaryFileHash` (`binaryFileHash`),
                            KEY `autoSave` (`autoSave`),
                            KEY `stackTrace` (`stackTrace`(1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webdav_locks`
--

DROP TABLE IF EXISTS `webdav_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webdav_locks` (
                                `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                                `owner` varchar(100) DEFAULT NULL,
                                `timeout` int(10) unsigned DEFAULT NULL,
                                `created` int(11) DEFAULT NULL,
                                `token` varbinary(100) DEFAULT NULL,
                                `scope` tinyint(4) DEFAULT NULL,
                                `depth` tinyint(4) DEFAULT NULL,
                                `uri` varbinary(1000) DEFAULT NULL,
                                PRIMARY KEY (`id`),
                                KEY `token` (`token`),
                                KEY `uri` (`uri`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webdav_locks`
--

LOCK TABLES `webdav_locks` WRITE;
/*!40000 ALTER TABLE `webdav_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webdav_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_settings`
--

DROP TABLE IF EXISTS `website_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_settings` (
                                    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                    `name` varchar(190) NOT NULL DEFAULT '',
                                    `type` enum('text','document','asset','object','bool') DEFAULT NULL,
                                    `data` text DEFAULT NULL,
                                    `language` varchar(15) NOT NULL DEFAULT '',
                                    `siteId` int(11) unsigned DEFAULT NULL,
                                    `creationDate` int(11) unsigned DEFAULT 0,
                                    `modificationDate` int(11) unsigned DEFAULT 0,
                                    PRIMARY KEY (`id`),
                                    KEY `name` (`name`),
                                    KEY `siteId` (`siteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_settings`
--

LOCK TABLES `website_settings` WRITE;
/*!40000 ALTER TABLE `website_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `website_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-03 13:35:34
-- MariaDB dump 10.19  Distrib 10.8.3-MariaDB, for osx10.16 (x86_64)
--
-- Host: 127.0.0.1    Database: froq_pimcore
-- ------------------------------------------------------
-- Server version	10.8.3-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_logs`
--

DROP TABLE IF EXISTS `application_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_logs` (
                                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                                    `pid` int(11) DEFAULT NULL,
                                    `timestamp` datetime NOT NULL,
                                    `message` text DEFAULT NULL,
                                    `priority` enum('emergency','alert','critical','error','warning','notice','info','debug') DEFAULT NULL,
                                    `fileobject` varchar(1024) DEFAULT NULL,
                                    `info` varchar(1024) DEFAULT NULL,
                                    `component` varchar(190) DEFAULT NULL,
                                    `source` varchar(190) DEFAULT NULL,
                                    `relatedobject` int(11) unsigned DEFAULT NULL,
                                    `relatedobjecttype` enum('object','document','asset') DEFAULT NULL,
                                    `maintenanceChecked` tinyint(1) DEFAULT NULL,
                                    PRIMARY KEY (`id`),
                                    KEY `component` (`component`),
                                    KEY `timestamp` (`timestamp`),
                                    KEY `relatedobject` (`relatedobject`),
                                    KEY `priority` (`priority`),
                                    KEY `maintenanceChecked` (`maintenanceChecked`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_logs`
--

LOCK TABLES `application_logs` WRITE;
/*!40000 ALTER TABLE `application_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
                          `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                          `parentId` int(11) unsigned DEFAULT NULL,
                          `type` varchar(20) DEFAULT NULL,
                          `filename` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
                          `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                          `mimetype` varchar(190) DEFAULT NULL,
                          `creationDate` int(11) unsigned DEFAULT NULL,
                          `modificationDate` int(11) unsigned DEFAULT NULL,
                          `userOwner` int(11) unsigned DEFAULT NULL,
                          `userModification` int(11) unsigned DEFAULT NULL,
                          `customSettings` longtext DEFAULT NULL,
                          `hasMetaData` tinyint(1) NOT NULL DEFAULT 0,
                          `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
                          PRIMARY KEY (`id`),
                          UNIQUE KEY `fullpath` (`path`,`filename`),
                          KEY `parentId` (`parentId`),
                          KEY `filename` (`filename`),
                          KEY `modificationDate` (`modificationDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES
    (1,0,'folder','','/',NULL,1657535401,1657535401,1,1,NULL,0,0);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_image_thumbnail_cache`
--

DROP TABLE IF EXISTS `assets_image_thumbnail_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_image_thumbnail_cache` (
                                                `cid` int(11) unsigned NOT NULL,
                                                `name` varchar(190) CHARACTER SET ascii NOT NULL,
                                                `filename` varchar(190) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
                                                `modificationDate` int(11) unsigned DEFAULT NULL,
                                                `filesize` int(10) unsigned DEFAULT NULL,
                                                `width` smallint(5) unsigned DEFAULT NULL,
                                                `height` smallint(5) unsigned DEFAULT NULL,
                                                PRIMARY KEY (`cid`,`name`,`filename`),
                                                CONSTRAINT `FK_assets_image_thumbnail_cache_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_image_thumbnail_cache`
--

LOCK TABLES `assets_image_thumbnail_cache` WRITE;
/*!40000 ALTER TABLE `assets_image_thumbnail_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_image_thumbnail_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_metadata`
--

DROP TABLE IF EXISTS `assets_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_metadata` (
                                   `cid` int(11) unsigned NOT NULL,
                                   `name` varchar(190) NOT NULL,
                                   `language` varchar(10) CHARACTER SET ascii NOT NULL DEFAULT '',
                                   `type` enum('input','textarea','asset','document','object','date','select','checkbox') DEFAULT NULL,
                                   `data` longtext DEFAULT NULL,
                                   PRIMARY KEY (`cid`,`name`,`language`),
                                   KEY `name` (`name`),
                                   CONSTRAINT `fk_assets_metadata_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_metadata`
--

LOCK TABLES `assets_metadata` WRITE;
/*!40000 ALTER TABLE `assets_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_data_hub_data_importer_delta_cache`
--

DROP TABLE IF EXISTS `bundle_data_hub_data_importer_delta_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_data_hub_data_importer_delta_cache` (
                                                             `configName` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
                                                             `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
                                                             `hash` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
                                                             PRIMARY KEY (`configName`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_data_hub_data_importer_delta_cache`
--

LOCK TABLES `bundle_data_hub_data_importer_delta_cache` WRITE;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_delta_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_delta_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_data_hub_data_importer_last_execution`
--

DROP TABLE IF EXISTS `bundle_data_hub_data_importer_last_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_data_hub_data_importer_last_execution` (
                                                                `configName` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
                                                                `lastExecutionDate` int(11) DEFAULT NULL,
                                                                PRIMARY KEY (`configName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_data_hub_data_importer_last_execution`
--

LOCK TABLES `bundle_data_hub_data_importer_last_execution` WRITE;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_last_execution` DISABLE KEYS */;
INSERT INTO `bundle_data_hub_data_importer_last_execution` VALUES
    ('test1',1660037366);
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_last_execution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bundle_data_hub_data_importer_queue`
--

DROP TABLE IF EXISTS `bundle_data_hub_data_importer_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_data_hub_data_importer_queue` (
                                                       `id` bigint(20) NOT NULL AUTO_INCREMENT,
                                                       `timestamp` bigint(20) DEFAULT NULL,
                                                       `configName` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       `data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       `executionType` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       `jobType` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       `dispatched` bigint(20) DEFAULT NULL,
                                                       `workerId` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                                       PRIMARY KEY (`id`),
                                                       KEY `bundle_index_queue_configName_index` (`configName`),
                                                       KEY `bundle_index_queue_configName_index_executionType` (`configName`,`executionType`),
                                                       KEY `bundle_index_queue_executiontype_workerId` (`executionType`,`workerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_data_hub_data_importer_queue`
--

LOCK TABLES `bundle_data_hub_data_importer_queue` WRITE;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `bundle_data_hub_data_importer_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_items`
--

DROP TABLE IF EXISTS `cache_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_items` (
                               `item_id` varbinary(255) NOT NULL,
                               `item_data` mediumblob NOT NULL,
                               `item_lifetime` int(10) unsigned DEFAULT NULL,
                               `item_time` int(10) unsigned NOT NULL,
                               PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_items`
--

LOCK TABLES `cache_items` WRITE;
/*!40000 ALTER TABLE `cache_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes` (
                           `id` varchar(50) NOT NULL,
                           `name` varchar(190) NOT NULL DEFAULT '',
                           PRIMARY KEY (`id`),
                           UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_collectionrelations`
--

DROP TABLE IF EXISTS `classificationstore_collectionrelations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_collectionrelations` (
                                                           `colId` int(11) unsigned NOT NULL,
                                                           `groupId` int(11) unsigned NOT NULL,
                                                           `sorter` int(10) DEFAULT 0,
                                                           PRIMARY KEY (`colId`,`groupId`),
                                                           KEY `FK_classificationstore_collectionrelations_groups` (`groupId`),
                                                           CONSTRAINT `FK_classificationstore_collectionrelations_groups` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_collectionrelations`
--

LOCK TABLES `classificationstore_collectionrelations` WRITE;
/*!40000 ALTER TABLE `classificationstore_collectionrelations` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_collectionrelations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_collections`
--

DROP TABLE IF EXISTS `classificationstore_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_collections` (
                                                   `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                                   `storeId` int(11) DEFAULT NULL,
                                                   `name` varchar(255) NOT NULL DEFAULT '',
                                                   `description` varchar(255) DEFAULT NULL,
                                                   `creationDate` int(11) unsigned DEFAULT 0,
                                                   `modificationDate` int(11) unsigned DEFAULT 0,
                                                   PRIMARY KEY (`id`),
                                                   KEY `storeId` (`storeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_collections`
--

LOCK TABLES `classificationstore_collections` WRITE;
/*!40000 ALTER TABLE `classificationstore_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_groups`
--

DROP TABLE IF EXISTS `classificationstore_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_groups` (
                                              `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                              `storeId` int(11) DEFAULT NULL,
                                              `parentId` int(11) unsigned NOT NULL DEFAULT 0,
                                              `name` varchar(190) NOT NULL DEFAULT '',
                                              `description` varchar(255) DEFAULT NULL,
                                              `creationDate` int(11) unsigned DEFAULT 0,
                                              `modificationDate` int(11) unsigned DEFAULT 0,
                                              PRIMARY KEY (`id`),
                                              KEY `storeId` (`storeId`),
                                              KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_groups`
--

LOCK TABLES `classificationstore_groups` WRITE;
/*!40000 ALTER TABLE `classificationstore_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_keys`
--

DROP TABLE IF EXISTS `classificationstore_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_keys` (
                                            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                            `storeId` int(11) DEFAULT NULL,
                                            `name` varchar(190) NOT NULL DEFAULT '',
                                            `title` varchar(255) NOT NULL DEFAULT '',
                                            `description` text DEFAULT NULL,
                                            `type` varchar(190) DEFAULT NULL,
                                            `creationDate` int(11) unsigned DEFAULT 0,
                                            `modificationDate` int(11) unsigned DEFAULT 0,
                                            `definition` longtext DEFAULT NULL,
                                            `enabled` tinyint(1) DEFAULT NULL,
                                            PRIMARY KEY (`id`),
                                            KEY `name` (`name`),
                                            KEY `enabled` (`enabled`),
                                            KEY `type` (`type`),
                                            KEY `storeId` (`storeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_keys`
--

LOCK TABLES `classificationstore_keys` WRITE;
/*!40000 ALTER TABLE `classificationstore_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_relations`
--

DROP TABLE IF EXISTS `classificationstore_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_relations` (
                                                 `groupId` int(11) unsigned NOT NULL,
                                                 `keyId` int(11) unsigned NOT NULL,
                                                 `sorter` int(11) DEFAULT NULL,
                                                 `mandatory` tinyint(1) DEFAULT NULL,
                                                 PRIMARY KEY (`groupId`,`keyId`),
                                                 KEY `FK_classificationstore_relations_classificationstore_keys` (`keyId`),
                                                 KEY `mandatory` (`mandatory`),
                                                 CONSTRAINT `FK_classificationstore_relations_classificationstore_groups` FOREIGN KEY (`groupId`) REFERENCES `classificationstore_groups` (`id`) ON DELETE CASCADE,
                                                 CONSTRAINT `FK_classificationstore_relations_classificationstore_keys` FOREIGN KEY (`keyId`) REFERENCES `classificationstore_keys` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_relations`
--

LOCK TABLES `classificationstore_relations` WRITE;
/*!40000 ALTER TABLE `classificationstore_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classificationstore_stores`
--

DROP TABLE IF EXISTS `classificationstore_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classificationstore_stores` (
                                              `id` int(11) NOT NULL AUTO_INCREMENT,
                                              `name` varchar(190) DEFAULT NULL,
                                              `description` longtext DEFAULT NULL,
                                              PRIMARY KEY (`id`),
                                              KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classificationstore_stores`
--

LOCK TABLES `classificationstore_stores` WRITE;
/*!40000 ALTER TABLE `classificationstore_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `classificationstore_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_layouts`
--

DROP TABLE IF EXISTS `custom_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_layouts` (
                                  `id` varchar(64) NOT NULL,
                                  `classId` varchar(50) NOT NULL,
                                  `name` varchar(190) DEFAULT NULL,
                                  `description` text DEFAULT NULL,
                                  `creationDate` int(11) unsigned DEFAULT NULL,
                                  `modificationDate` int(11) unsigned DEFAULT NULL,
                                  `userOwner` int(11) unsigned DEFAULT NULL,
                                  `userModification` int(11) unsigned DEFAULT NULL,
                                  `default` tinyint(1) NOT NULL DEFAULT 0,
                                  PRIMARY KEY (`id`),
                                  UNIQUE KEY `name` (`name`,`classId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_layouts`
--

LOCK TABLES `custom_layouts` WRITE;
/*!40000 ALTER TABLE `custom_layouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_layouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependencies`
--

DROP TABLE IF EXISTS `dependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dependencies` (
                                `id` bigint(20) NOT NULL AUTO_INCREMENT,
                                `sourcetype` enum('document','asset','object') NOT NULL DEFAULT 'document',
                                `sourceid` int(11) unsigned NOT NULL DEFAULT 0,
                                `targettype` enum('document','asset','object') NOT NULL DEFAULT 'document',
                                `targetid` int(11) unsigned NOT NULL DEFAULT 0,
                                PRIMARY KEY (`id`),
                                UNIQUE KEY `combi` (`sourcetype`,`sourceid`,`targettype`,`targetid`),
                                KEY `targettype_targetid` (`targettype`,`targetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dependencies`
--

LOCK TABLES `dependencies` WRITE;
/*!40000 ALTER TABLE `dependencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dependencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
                             `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                             `parentId` int(11) unsigned DEFAULT NULL,
                             `type` enum('page','link','snippet','folder','hardlink','email','newsletter','printpage','printcontainer') DEFAULT NULL,
                             `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
                             `path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                             `index` int(11) unsigned DEFAULT 0,
                             `published` tinyint(1) unsigned DEFAULT 1,
                             `creationDate` int(11) unsigned DEFAULT NULL,
                             `modificationDate` int(11) unsigned DEFAULT NULL,
                             `userOwner` int(11) unsigned DEFAULT NULL,
                             `userModification` int(11) unsigned DEFAULT NULL,
                             `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
                             PRIMARY KEY (`id`),
                             UNIQUE KEY `fullpath` (`path`,`key`),
                             KEY `parentId` (`parentId`),
                             KEY `key` (`key`),
                             KEY `published` (`published`),
                             KEY `modificationDate` (`modificationDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES
    (1,0,'page','','/',999999,1,1657535401,1657535401,1,1,0);
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_editables`
--

DROP TABLE IF EXISTS `documents_editables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_editables` (
                                       `documentId` int(11) unsigned NOT NULL DEFAULT 0,
                                       `name` varchar(750) CHARACTER SET ascii NOT NULL DEFAULT '',
                                       `type` varchar(50) DEFAULT NULL,
                                       `data` longtext DEFAULT NULL,
                                       PRIMARY KEY (`documentId`,`name`),
                                       CONSTRAINT `fk_documents_editables_documents` FOREIGN KEY (`documentId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_editables`
--

LOCK TABLES `documents_editables` WRITE;
/*!40000 ALTER TABLE `documents_editables` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_editables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_email`
--

DROP TABLE IF EXISTS `documents_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_email` (
                                   `id` int(11) unsigned NOT NULL DEFAULT 0,
                                   `controller` varchar(500) DEFAULT NULL,
                                   `template` varchar(255) DEFAULT NULL,
                                   `to` varchar(255) DEFAULT NULL,
                                   `from` varchar(255) DEFAULT NULL,
                                   `replyTo` varchar(255) DEFAULT NULL,
                                   `cc` varchar(255) DEFAULT NULL,
                                   `bcc` varchar(255) DEFAULT NULL,
                                   `subject` varchar(255) DEFAULT NULL,
                                   `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                   PRIMARY KEY (`id`),
                                   CONSTRAINT `fk_documents_email_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_email`
--

LOCK TABLES `documents_email` WRITE;
/*!40000 ALTER TABLE `documents_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_hardlink`
--

DROP TABLE IF EXISTS `documents_hardlink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_hardlink` (
                                      `id` int(11) unsigned NOT NULL DEFAULT 0,
                                      `sourceId` int(11) DEFAULT NULL,
                                      `propertiesFromSource` tinyint(1) DEFAULT NULL,
                                      `childrenFromSource` tinyint(1) DEFAULT NULL,
                                      PRIMARY KEY (`id`),
                                      KEY `sourceId` (`sourceId`),
                                      CONSTRAINT `fk_documents_hardlink_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_hardlink`
--

LOCK TABLES `documents_hardlink` WRITE;
/*!40000 ALTER TABLE `documents_hardlink` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_hardlink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_link`
--

DROP TABLE IF EXISTS `documents_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_link` (
                                  `id` int(11) unsigned NOT NULL DEFAULT 0,
                                  `internalType` enum('document','asset','object') DEFAULT NULL,
                                  `internal` int(11) unsigned DEFAULT NULL,
                                  `direct` varchar(1000) DEFAULT NULL,
                                  `linktype` enum('direct','internal') DEFAULT NULL,
                                  PRIMARY KEY (`id`),
                                  CONSTRAINT `fk_documents_link_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_link`
--

LOCK TABLES `documents_link` WRITE;
/*!40000 ALTER TABLE `documents_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_newsletter`
--

DROP TABLE IF EXISTS `documents_newsletter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_newsletter` (
                                        `id` int(11) unsigned NOT NULL DEFAULT 0,
                                        `controller` varchar(500) DEFAULT NULL,
                                        `template` varchar(255) DEFAULT NULL,
                                        `from` varchar(255) DEFAULT NULL,
                                        `subject` varchar(255) DEFAULT NULL,
                                        `trackingParameterSource` varchar(255) DEFAULT NULL,
                                        `trackingParameterMedium` varchar(255) DEFAULT NULL,
                                        `trackingParameterName` varchar(255) DEFAULT NULL,
                                        `enableTrackingParameters` tinyint(1) unsigned DEFAULT NULL,
                                        `sendingMode` varchar(20) DEFAULT NULL,
                                        `plaintext` longtext DEFAULT NULL,
                                        `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                        PRIMARY KEY (`id`),
                                        CONSTRAINT `fk_documents_newsletter_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_newsletter`
--

LOCK TABLES `documents_newsletter` WRITE;
/*!40000 ALTER TABLE `documents_newsletter` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_newsletter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_page`
--

DROP TABLE IF EXISTS `documents_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_page` (
                                  `id` int(11) unsigned NOT NULL DEFAULT 0,
                                  `controller` varchar(500) DEFAULT NULL,
                                  `template` varchar(255) DEFAULT NULL,
                                  `title` varchar(255) DEFAULT NULL,
                                  `description` varchar(383) DEFAULT NULL,
                                  `metaData` text DEFAULT NULL,
                                  `prettyUrl` varchar(255) DEFAULT NULL,
                                  `contentMasterDocumentId` int(11) DEFAULT NULL,
                                  `targetGroupIds` varchar(255) NOT NULL DEFAULT '',
                                  `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                  `staticGeneratorEnabled` tinyint(1) unsigned DEFAULT NULL,
                                  `staticGeneratorLifetime` int(11) DEFAULT NULL,
                                  PRIMARY KEY (`id`),
                                  KEY `prettyUrl` (`prettyUrl`),
                                  CONSTRAINT `fk_documents_page_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_page`
--

LOCK TABLES `documents_page` WRITE;
/*!40000 ALTER TABLE `documents_page` DISABLE KEYS */;
INSERT INTO `documents_page` VALUES
    (1,'App\\Controller\\DefaultController::defaultAction','','','',NULL,NULL,NULL,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `documents_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_printpage`
--

DROP TABLE IF EXISTS `documents_printpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_printpage` (
                                       `id` int(11) unsigned NOT NULL DEFAULT 0,
                                       `controller` varchar(500) DEFAULT NULL,
                                       `template` varchar(255) DEFAULT NULL,
                                       `lastGenerated` int(11) DEFAULT NULL,
                                       `lastGenerateMessage` text DEFAULT NULL,
                                       `contentMasterDocumentId` int(11) DEFAULT NULL,
                                       `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                       PRIMARY KEY (`id`),
                                       CONSTRAINT `fk_documents_printpage_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_printpage`
--

LOCK TABLES `documents_printpage` WRITE;
/*!40000 ALTER TABLE `documents_printpage` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_printpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_snippet`
--

DROP TABLE IF EXISTS `documents_snippet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_snippet` (
                                     `id` int(11) unsigned NOT NULL DEFAULT 0,
                                     `controller` varchar(500) DEFAULT NULL,
                                     `template` varchar(255) DEFAULT NULL,
                                     `contentMasterDocumentId` int(11) DEFAULT NULL,
                                     `missingRequiredEditable` tinyint(1) unsigned DEFAULT NULL,
                                     PRIMARY KEY (`id`),
                                     CONSTRAINT `fk_documents_snippet_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_snippet`
--

LOCK TABLES `documents_snippet` WRITE;
/*!40000 ALTER TABLE `documents_snippet` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_snippet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_translations`
--

DROP TABLE IF EXISTS `documents_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_translations` (
                                          `id` int(11) unsigned NOT NULL DEFAULT 0,
                                          `sourceId` int(11) unsigned NOT NULL DEFAULT 0,
                                          `language` varchar(10) NOT NULL DEFAULT '',
                                          PRIMARY KEY (`sourceId`,`language`),
                                          KEY `id` (`id`),
                                          KEY `language` (`language`),
                                          CONSTRAINT `fk_documents_translations_documents` FOREIGN KEY (`id`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_translations`
--

LOCK TABLES `documents_translations` WRITE;
/*!40000 ALTER TABLE `documents_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edit_lock`
--

DROP TABLE IF EXISTS `edit_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edit_lock` (
                             `id` int(11) NOT NULL AUTO_INCREMENT,
                             `cid` int(11) unsigned NOT NULL DEFAULT 0,
                             `ctype` enum('document','asset','object') DEFAULT NULL,
                             `userId` int(11) unsigned NOT NULL DEFAULT 0,
                             `sessionId` varchar(255) DEFAULT NULL,
                             `date` int(11) unsigned DEFAULT NULL,
                             PRIMARY KEY (`id`),
                             KEY `ctype` (`ctype`),
                             KEY `cidtype` (`cid`,`ctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edit_lock`
--

LOCK TABLES `edit_lock` WRITE;
/*!40000 ALTER TABLE `edit_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `edit_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `element_workflow_state`
--

DROP TABLE IF EXISTS `element_workflow_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `element_workflow_state` (
                                          `cid` int(10) NOT NULL DEFAULT 0,
                                          `ctype` enum('document','asset','object') NOT NULL,
                                          `place` text DEFAULT NULL,
                                          `workflow` varchar(100) NOT NULL,
                                          PRIMARY KEY (`cid`,`ctype`,`workflow`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `element_workflow_state`
--

LOCK TABLES `element_workflow_state` WRITE;
/*!40000 ALTER TABLE `element_workflow_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `element_workflow_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_blacklist`
--

DROP TABLE IF EXISTS `email_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_blacklist` (
                                   `address` varchar(190) NOT NULL DEFAULT '',
                                   `creationDate` int(11) unsigned DEFAULT NULL,
                                   `modificationDate` int(11) unsigned DEFAULT NULL,
                                   PRIMARY KEY (`address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_blacklist`
--

LOCK TABLES `email_blacklist` WRITE;
/*!40000 ALTER TABLE `email_blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_log` (
                             `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                             `documentId` int(11) unsigned DEFAULT NULL,
                             `requestUri` varchar(500) DEFAULT NULL,
                             `params` text DEFAULT NULL,
                             `from` varchar(500) DEFAULT NULL,
                             `replyTo` varchar(255) DEFAULT NULL,
                             `to` longtext DEFAULT NULL,
                             `cc` longtext DEFAULT NULL,
                             `bcc` longtext DEFAULT NULL,
                             `sentDate` int(11) unsigned DEFAULT NULL,
                             `subject` varchar(500) DEFAULT NULL,
                             `error` text DEFAULT NULL,
                             PRIMARY KEY (`id`),
                             KEY `sentDate` (`sentDate`,`id`),
                             KEY `document_id` (`documentId`),
                             FULLTEXT KEY `fulltext` (`from`,`to`,`cc`,`bcc`,`subject`,`params`),
                             CONSTRAINT `fk_email_log_documents` FOREIGN KEY (`documentId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary`
--

DROP TABLE IF EXISTS `glossary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glossary` (
                            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                            `language` varchar(10) DEFAULT NULL,
                            `casesensitive` tinyint(1) DEFAULT NULL,
                            `exactmatch` tinyint(1) DEFAULT NULL,
                            `text` varchar(255) DEFAULT NULL,
                            `link` varchar(255) DEFAULT NULL,
                            `abbr` varchar(255) DEFAULT NULL,
                            `site` int(11) unsigned DEFAULT NULL,
                            `creationDate` int(11) unsigned DEFAULT 0,
                            `modificationDate` int(11) unsigned DEFAULT 0,
                            PRIMARY KEY (`id`),
                            KEY `language` (`language`),
                            KEY `site` (`site`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glossary`
--

LOCK TABLES `glossary` WRITE;
/*!40000 ALTER TABLE `glossary` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfig_favourites`
--

DROP TABLE IF EXISTS `gridconfig_favourites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gridconfig_favourites` (
                                         `ownerId` int(11) NOT NULL,
                                         `classId` varchar(50) NOT NULL,
                                         `objectId` int(11) NOT NULL DEFAULT 0,
                                         `gridConfigId` int(11) NOT NULL,
                                         `searchType` varchar(50) NOT NULL DEFAULT '',
                                         `type` enum('asset','object') NOT NULL DEFAULT 'object',
                                         PRIMARY KEY (`ownerId`,`classId`,`searchType`,`objectId`),
                                         KEY `classId` (`classId`),
                                         KEY `searchType` (`searchType`),
                                         KEY `grid_config_id` (`gridConfigId`),
                                         CONSTRAINT `fk_gridconfig_favourites_gridconfigs` FOREIGN KEY (`gridConfigId`) REFERENCES `gridconfigs` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfig_favourites`
--

LOCK TABLES `gridconfig_favourites` WRITE;
/*!40000 ALTER TABLE `gridconfig_favourites` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfig_favourites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfig_shares`
--

DROP TABLE IF EXISTS `gridconfig_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gridconfig_shares` (
                                     `gridConfigId` int(11) NOT NULL,
                                     `sharedWithUserId` int(11) NOT NULL,
                                     PRIMARY KEY (`gridConfigId`,`sharedWithUserId`),
                                     KEY `sharedWithUserId` (`sharedWithUserId`),
                                     KEY `grid_config_id` (`gridConfigId`),
                                     CONSTRAINT `fk_gridconfig_shares_gridconfigs` FOREIGN KEY (`gridConfigId`) REFERENCES `gridconfigs` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfig_shares`
--

LOCK TABLES `gridconfig_shares` WRITE;
/*!40000 ALTER TABLE `gridconfig_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfig_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gridconfigs`
--

DROP TABLE IF EXISTS `gridconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gridconfigs` (
                               `id` int(11) NOT NULL AUTO_INCREMENT,
                               `ownerId` int(11) DEFAULT NULL,
                               `classId` varchar(50) DEFAULT NULL,
                               `name` varchar(50) DEFAULT NULL,
                               `searchType` varchar(50) DEFAULT NULL,
                               `type` enum('asset','object') NOT NULL DEFAULT 'object',
                               `config` longtext DEFAULT NULL,
                               `description` longtext DEFAULT NULL,
                               `creationDate` int(11) DEFAULT NULL,
                               `modificationDate` int(11) DEFAULT NULL,
                               `shareGlobally` tinyint(1) DEFAULT NULL,
                               PRIMARY KEY (`id`),
                               KEY `ownerId` (`ownerId`),
                               KEY `classId` (`classId`),
                               KEY `searchType` (`searchType`),
                               KEY `shareGlobally` (`shareGlobally`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gridconfigs`
--

LOCK TABLES `gridconfigs` WRITE;
/*!40000 ALTER TABLE `gridconfigs` DISABLE KEYS */;
/*!40000 ALTER TABLE `gridconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `http_error_log`
--

DROP TABLE IF EXISTS `http_error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `http_error_log` (
                                  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                  `uri` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                                  `code` int(3) DEFAULT NULL,
                                  `parametersGet` longtext DEFAULT NULL,
                                  `parametersPost` longtext DEFAULT NULL,
                                  `cookies` longtext DEFAULT NULL,
                                  `serverVars` longtext DEFAULT NULL,
                                  `date` int(11) unsigned DEFAULT NULL,
                                  `count` bigint(20) unsigned DEFAULT NULL,
                                  PRIMARY KEY (`id`),
                                  KEY `uri` (`uri`),
                                  KEY `code` (`code`),
                                  KEY `date` (`date`),
                                  KEY `count` (`count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `http_error_log`
--

LOCK TABLES `http_error_log` WRITE;
/*!40000 ALTER TABLE `http_error_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `http_error_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importconfig_shares`
--

DROP TABLE IF EXISTS `importconfig_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importconfig_shares` (
                                       `importConfigId` int(11) NOT NULL,
                                       `sharedWithUserId` int(11) NOT NULL,
                                       PRIMARY KEY (`importConfigId`,`sharedWithUserId`),
                                       KEY `sharedWithUserId` (`sharedWithUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importconfig_shares`
--

LOCK TABLES `importconfig_shares` WRITE;
/*!40000 ALTER TABLE `importconfig_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `importconfig_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importconfigs`
--

DROP TABLE IF EXISTS `importconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importconfigs` (
                                 `id` int(11) NOT NULL AUTO_INCREMENT,
                                 `ownerId` int(11) DEFAULT NULL,
                                 `classId` varchar(50) DEFAULT NULL,
                                 `name` varchar(50) DEFAULT NULL,
                                 `config` longtext DEFAULT NULL,
                                 `description` longtext DEFAULT NULL,
                                 `creationDate` int(11) DEFAULT NULL,
                                 `modificationDate` int(11) DEFAULT NULL,
                                 `shareGlobally` tinyint(1) DEFAULT NULL,
                                 PRIMARY KEY (`id`),
                                 KEY `ownerId` (`ownerId`),
                                 KEY `classId` (`classId`),
                                 KEY `shareGlobally` (`shareGlobally`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importconfigs`
--

LOCK TABLES `importconfigs` WRITE;
/*!40000 ALTER TABLE `importconfigs` DISABLE KEYS */;
/*!40000 ALTER TABLE `importconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lock_keys`
--

DROP TABLE IF EXISTS `lock_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lock_keys` (
                             `key_id` varchar(64) NOT NULL,
                             `key_token` varchar(44) NOT NULL,
                             `key_expiration` int(10) unsigned NOT NULL,
                             PRIMARY KEY (`key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lock_keys`
--

LOCK TABLES `lock_keys` WRITE;
/*!40000 ALTER TABLE `lock_keys` DISABLE KEYS */;
INSERT INTO `lock_keys` VALUES
    ('65b8fc17a1cbbf3557066e114a07ecb3f5a15ce61423affe7a032548fb255afb','81Dy5gkaAcuKul7iqMWm5sPCXMGyxoy3PT/sNcVh0NI=',1664809803);
/*!40000 ALTER TABLE `lock_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
                                      `id` bigint(20) NOT NULL AUTO_INCREMENT,
                                      `body` longtext NOT NULL,
                                      `headers` longtext NOT NULL,
                                      `queue_name` varchar(190) NOT NULL,
                                      `created_at` datetime NOT NULL,
                                      `available_at` datetime NOT NULL,
                                      `delivered_at` datetime DEFAULT NULL,
                                      PRIMARY KEY (`id`),
                                      KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
                                      KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
                                      KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB AUTO_INCREMENT=195623 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration_versions` (
                                      `version` varchar(1024) COLLATE utf8mb3_unicode_ci NOT NULL,
                                      `executed_at` datetime DEFAULT NULL,
                                      `execution_time` int(11) DEFAULT NULL,
                                      PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008082752',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008091131',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008101817',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201008132324',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201009095924',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201012154224',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201014101437',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201113143914',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20201201084201',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210107103923',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210218142556',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210323082921',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210323110055',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210324152821',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210324152822',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210330132354',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210408153226',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210412112812',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210428145320',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210430124911',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210505093841',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210531125102',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210608094532',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210616114744',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210624085031',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210630062445',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210702102100',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210706090823',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210901130000',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20210928135248',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211016084043',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211018104331',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211028134037',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211028155535',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211103055110',NULL,NULL),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211117173000','2022-08-09 09:47:52',59),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211209131141','2022-08-09 09:47:52',440),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20211221152344','2022-08-09 09:47:52',31),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220119082511','2022-08-09 09:47:53',50),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220120121803','2022-08-09 09:47:53',138),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220120162621','2022-08-09 09:47:53',560),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220201132131','2022-08-09 09:47:53',1),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220214110000','2022-08-09 09:47:53',435),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220317125711','2022-08-09 09:47:54',367),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220318101020','2022-08-09 09:47:54',0),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220402104849','2022-08-09 09:47:54',24),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220411172543','2022-08-09 09:47:54',2),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220419120333','2022-08-09 09:47:54',430),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220425082914','2022-08-09 09:47:55',14),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220502104200','2022-08-09 09:47:55',22),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220506103100','2022-08-09 09:47:55',364),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220511085800','2022-08-09 09:47:55',494),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220718162200','2022-08-09 09:47:55',13),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version20220725154615','2022-08-09 09:47:55',359),
                                     ('Pimcore\\Bundle\\CoreBundle\\Migrations\\Version22020614115124','2022-08-09 09:47:56',387),
                                     ('Pimcore\\Bundle\\DataHubBundle\\Migrations\\PimcoreX\\Version20210305134111',NULL,NULL),
                                     ('Pimcore\\Bundle\\DataHubBundle\\Migrations\\PimcoreX\\Version20211108160248','2022-08-09 11:19:48',43),
                                     ('Pimcore\\Bundle\\DataImporterBundle\\Migrations\\Version20210305134111','2022-08-09 09:47:56',3),
                                     ('Pimcore\\Bundle\\DataImporterBundle\\Migrations\\Version20211110174732','2022-08-09 09:47:56',404),
                                     ('Pimcore\\Bundle\\DataImporterBundle\\Migrations\\Version20211201173215','2022-08-09 09:47:57',462),
                                     ('Pimcore\\Bundle\\DataImporterBundle\\Migrations\\Version20220304130000','2022-08-09 09:47:57',406);
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `type` varchar(255) DEFAULT NULL,
                         `cid` int(11) DEFAULT NULL,
                         `ctype` enum('asset','document','object') DEFAULT NULL,
                         `date` int(11) DEFAULT NULL,
                         `user` int(11) DEFAULT NULL,
                         `title` varchar(255) DEFAULT NULL,
                         `description` longtext DEFAULT NULL,
                         PRIMARY KEY (`id`),
                         KEY `cid_ctype` (`cid`,`ctype`),
                         KEY `date` (`date`),
                         KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes_data`
--

DROP TABLE IF EXISTS `notes_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes_data` (
                              `id` int(11) NOT NULL,
                              `name` varchar(255) NOT NULL,
                              `type` enum('text','date','document','asset','object','bool') DEFAULT NULL,
                              `data` text DEFAULT NULL,
                              PRIMARY KEY (`id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes_data`
--

LOCK TABLES `notes_data` WRITE;
/*!40000 ALTER TABLE `notes_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
                                 `id` int(11) NOT NULL AUTO_INCREMENT,
                                 `type` varchar(20) NOT NULL DEFAULT 'info',
                                 `title` varchar(250) NOT NULL DEFAULT '',
                                 `message` text NOT NULL,
                                 `sender` int(11) DEFAULT NULL,
                                 `recipient` int(11) NOT NULL,
                                 `read` tinyint(1) NOT NULL DEFAULT 0,
                                 `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
                                 `modificationDate` timestamp NULL DEFAULT NULL,
                                 `linkedElementType` enum('document','asset','object') DEFAULT NULL,
                                 `linkedElement` int(11) DEFAULT NULL,
                                 PRIMARY KEY (`id`),
                                 KEY `recipient` (`recipient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_url_slugs`
--

DROP TABLE IF EXISTS `object_url_slugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_url_slugs` (
                                    `objectId` int(11) unsigned NOT NULL DEFAULT 0,
                                    `classId` varchar(50) NOT NULL DEFAULT '0',
                                    `fieldname` varchar(70) NOT NULL DEFAULT '0',
                                    `index` int(11) unsigned NOT NULL DEFAULT 0,
                                    `ownertype` enum('object','fieldcollection','localizedfield','objectbrick') NOT NULL DEFAULT 'object',
                                    `ownername` varchar(70) NOT NULL DEFAULT '',
                                    `position` varchar(70) NOT NULL DEFAULT '0',
                                    `slug` varchar(765) NOT NULL,
                                    `siteId` int(11) NOT NULL DEFAULT 0,
                                    PRIMARY KEY (`slug`,`siteId`),
                                    KEY `index` (`index`),
                                    KEY `objectId` (`objectId`),
                                    KEY `classId` (`classId`),
                                    KEY `fieldname` (`fieldname`),
                                    KEY `position` (`position`),
                                    KEY `ownertype` (`ownertype`),
                                    KEY `ownername` (`ownername`),
                                    KEY `slug` (`slug`),
                                    KEY `siteId` (`siteId`),
                                    KEY `fieldname_ownertype_position_objectId` (`fieldname`,`ownertype`,`position`,`objectId`),
                                    CONSTRAINT `fk_object_url_slugs__objectId` FOREIGN KEY (`objectId`) REFERENCES `objects` (`o_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_url_slugs`
--

LOCK TABLES `object_url_slugs` WRITE;
/*!40000 ALTER TABLE `object_url_slugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_url_slugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objects`
--

DROP TABLE IF EXISTS `objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objects` (
                           `o_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                           `o_parentId` int(11) unsigned DEFAULT NULL,
                           `o_type` enum('object','folder','variant') DEFAULT NULL,
                           `o_key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
                           `o_path` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                           `o_index` int(11) unsigned DEFAULT 0,
                           `o_published` tinyint(1) unsigned DEFAULT 1,
                           `o_creationDate` int(11) unsigned DEFAULT NULL,
                           `o_modificationDate` int(11) unsigned DEFAULT NULL,
                           `o_userOwner` int(11) unsigned DEFAULT NULL,
                           `o_userModification` int(11) unsigned DEFAULT NULL,
                           `o_classId` varchar(50) DEFAULT NULL,
                           `o_className` varchar(255) DEFAULT NULL,
                           `o_childrenSortBy` enum('key','index') DEFAULT NULL,
                           `o_childrenSortOrder` enum('ASC','DESC') DEFAULT NULL,
                           `o_versionCount` int(10) unsigned NOT NULL DEFAULT 0,
                           PRIMARY KEY (`o_id`),
                           UNIQUE KEY `fullpath` (`o_path`,`o_key`),
                           KEY `key` (`o_key`),
                           KEY `index` (`o_index`),
                           KEY `published` (`o_published`),
                           KEY `parentId` (`o_parentId`),
                           KEY `o_modificationDate` (`o_modificationDate`),
                           KEY `o_classId` (`o_classId`),
                           KEY `type_path_classId` (`o_type`,`o_path`,`o_classId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objects`
--

LOCK TABLES `objects` WRITE;
/*!40000 ALTER TABLE `objects` DISABLE KEYS */;
INSERT INTO `objects` VALUES
    (1,0,'folder','','/',999999,1,1657535401,1657535401,1,1,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_datahub_workspaces_asset`
--

DROP TABLE IF EXISTS `plugin_datahub_workspaces_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin_datahub_workspaces_asset` (
                                                   `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                                   `cpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                                                   `configuration` varchar(80) NOT NULL DEFAULT '0',
                                                   `create` tinyint(1) unsigned DEFAULT 0,
                                                   `read` tinyint(1) unsigned DEFAULT 0,
                                                   `update` tinyint(1) unsigned DEFAULT 0,
                                                   `delete` tinyint(1) unsigned DEFAULT 0,
                                                   PRIMARY KEY (`cid`,`configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_datahub_workspaces_asset`
--

LOCK TABLES `plugin_datahub_workspaces_asset` WRITE;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_datahub_workspaces_document`
--

DROP TABLE IF EXISTS `plugin_datahub_workspaces_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin_datahub_workspaces_document` (
                                                      `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                                      `cpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                                                      `configuration` varchar(80) NOT NULL DEFAULT '0',
                                                      `create` tinyint(1) unsigned DEFAULT 0,
                                                      `read` tinyint(1) unsigned DEFAULT 0,
                                                      `update` tinyint(1) unsigned DEFAULT 0,
                                                      `delete` tinyint(1) unsigned DEFAULT 0,
                                                      PRIMARY KEY (`cid`,`configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_datahub_workspaces_document`
--

LOCK TABLES `plugin_datahub_workspaces_document` WRITE;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_datahub_workspaces_object`
--

DROP TABLE IF EXISTS `plugin_datahub_workspaces_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin_datahub_workspaces_object` (
                                                    `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                                    `cpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                                                    `configuration` varchar(80) NOT NULL DEFAULT '0',
                                                    `create` tinyint(1) unsigned DEFAULT 0,
                                                    `read` tinyint(1) unsigned DEFAULT 0,
                                                    `update` tinyint(1) unsigned DEFAULT 0,
                                                    `delete` tinyint(1) unsigned DEFAULT 0,
                                                    PRIMARY KEY (`cid`,`configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_datahub_workspaces_object`
--

LOCK TABLES `plugin_datahub_workspaces_object` WRITE;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugin_datahub_workspaces_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `properties` (
                              `cid` int(11) unsigned NOT NULL DEFAULT 0,
                              `ctype` enum('document','asset','object') NOT NULL DEFAULT 'document',
                              `cpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                              `name` varchar(190) NOT NULL DEFAULT '',
                              `type` enum('text','document','asset','object','bool','select') DEFAULT NULL,
                              `data` text DEFAULT NULL,
                              `inheritable` tinyint(1) unsigned DEFAULT 1,
                              PRIMARY KEY (`cid`,`ctype`,`name`),
                              KEY `getall` (`cpath`,`ctype`,`inheritable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties`
--

LOCK TABLES `properties` WRITE;
/*!40000 ALTER TABLE `properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quantityvalue_units`
--

DROP TABLE IF EXISTS `quantityvalue_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quantityvalue_units` (
                                       `id` varchar(50) NOT NULL,
                                       `group` varchar(50) DEFAULT NULL,
                                       `abbreviation` varchar(20) DEFAULT NULL,
                                       `longname` varchar(250) DEFAULT NULL,
                                       `baseunit` varchar(50) DEFAULT NULL,
                                       `factor` double DEFAULT NULL,
                                       `conversionOffset` double DEFAULT NULL,
                                       `reference` varchar(50) DEFAULT NULL,
                                       `converter` varchar(255) DEFAULT NULL,
                                       PRIMARY KEY (`id`),
                                       KEY `fk_baseunit` (`baseunit`),
                                       CONSTRAINT `fk_baseunit` FOREIGN KEY (`baseunit`) REFERENCES `quantityvalue_units` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quantityvalue_units`
--

LOCK TABLES `quantityvalue_units` WRITE;
/*!40000 ALTER TABLE `quantityvalue_units` DISABLE KEYS */;
/*!40000 ALTER TABLE `quantityvalue_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recyclebin`
--

DROP TABLE IF EXISTS `recyclebin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recyclebin` (
                              `id` int(11) NOT NULL AUTO_INCREMENT,
                              `type` varchar(20) DEFAULT NULL,
                              `subtype` varchar(20) DEFAULT NULL,
                              `path` varchar(765) DEFAULT NULL,
                              `amount` int(3) DEFAULT NULL,
                              `date` int(11) unsigned DEFAULT NULL,
                              `deletedby` varchar(50) DEFAULT NULL,
                              PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recyclebin`
--

LOCK TABLES `recyclebin` WRITE;
/*!40000 ALTER TABLE `recyclebin` DISABLE KEYS */;
/*!40000 ALTER TABLE `recyclebin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redirects`
--

DROP TABLE IF EXISTS `redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redirects` (
                             `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                             `type` enum('entire_uri','path_query','path','auto_create') NOT NULL,
                             `source` varchar(255) DEFAULT NULL,
                             `sourceSite` int(11) DEFAULT NULL,
                             `target` varchar(255) DEFAULT NULL,
                             `targetSite` int(11) DEFAULT NULL,
                             `statusCode` varchar(3) DEFAULT NULL,
                             `priority` int(2) DEFAULT 0,
                             `regex` tinyint(1) DEFAULT NULL,
                             `passThroughParameters` tinyint(1) DEFAULT NULL,
                             `active` tinyint(1) DEFAULT NULL,
                             `expiry` int(11) unsigned DEFAULT NULL,
                             `creationDate` int(11) unsigned DEFAULT 0,
                             `modificationDate` int(11) unsigned DEFAULT 0,
                             `userOwner` int(11) unsigned DEFAULT NULL,
                             `userModification` int(11) unsigned DEFAULT NULL,
                             PRIMARY KEY (`id`),
                             KEY `priority` (`priority`),
                             KEY `routing_lookup` (`active`,`regex`,`sourceSite`,`source`,`type`,`expiry`,`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redirects`
--

LOCK TABLES `redirects` WRITE;
/*!40000 ALTER TABLE `redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_tasks`
--

DROP TABLE IF EXISTS `schedule_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_tasks` (
                                  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                  `cid` int(11) unsigned DEFAULT NULL,
                                  `ctype` enum('document','asset','object') DEFAULT NULL,
                                  `date` int(11) unsigned DEFAULT NULL,
                                  `action` enum('publish','unpublish','delete','publish-version') DEFAULT NULL,
                                  `version` bigint(20) unsigned DEFAULT NULL,
                                  `active` tinyint(1) unsigned DEFAULT 0,
                                  `userId` int(11) unsigned DEFAULT NULL,
                                  PRIMARY KEY (`id`),
                                  KEY `cid` (`cid`),
                                  KEY `ctype` (`ctype`),
                                  KEY `active` (`active`),
                                  KEY `version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_tasks`
--

LOCK TABLES `schedule_tasks` WRITE;
/*!40000 ALTER TABLE `schedule_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_backend_data`
--

DROP TABLE IF EXISTS `search_backend_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_backend_data` (
                                       `id` int(11) NOT NULL,
                                       `fullpath` varchar(765) CHARACTER SET utf8mb3 DEFAULT NULL,
                                       `maintype` varchar(8) NOT NULL DEFAULT '',
                                       `type` varchar(20) DEFAULT NULL,
                                       `subtype` varchar(190) DEFAULT NULL,
                                       `published` tinyint(1) unsigned DEFAULT NULL,
                                       `creationDate` int(11) unsigned DEFAULT NULL,
                                       `modificationDate` int(11) unsigned DEFAULT NULL,
                                       `userOwner` int(11) DEFAULT NULL,
                                       `userModification` int(11) DEFAULT NULL,
                                       `data` longtext DEFAULT NULL,
                                       `properties` text DEFAULT NULL,
                                       `key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT '',
                                       `index` int(11) unsigned DEFAULT 0,
                                       PRIMARY KEY (`id`,`maintype`),
                                       KEY `fullpath` (`fullpath`),
                                       KEY `maintype` (`maintype`),
                                       KEY `type` (`type`),
                                       KEY `subtype` (`subtype`),
                                       KEY `published` (`published`),
                                       KEY `key` (`key`),
                                       KEY `index` (`index`),
                                       FULLTEXT KEY `fulltext` (`data`,`properties`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_backend_data`
--

LOCK TABLES `search_backend_data` WRITE;
/*!40000 ALTER TABLE `search_backend_data` DISABLE KEYS */;
INSERT INTO `search_backend_data` VALUES
                                      (1,'/','asset','folder','folder',1,1657535401,1657535401,1,1,'ID: 1  \nPath: /  \n','','',NULL),
                                      (1,'/','document','page','page',1,1657535401,1657535401,1,1,'ID: 1  \nPath: /  \n','','',999999),
                                      (1,'/','object','folder','folder',1,1657535401,1657535401,1,1,'ID: 1  \nPath: /  \n','','',NULL);
/*!40000 ALTER TABLE `search_backend_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings_store`
--

DROP TABLE IF EXISTS `settings_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings_store` (
                                  `id` varchar(190) NOT NULL DEFAULT '',
                                  `scope` varchar(190) NOT NULL DEFAULT '',
                                  `data` longtext DEFAULT NULL,
                                  `type` enum('bool','int','float','string') NOT NULL DEFAULT 'string',
                                  PRIMARY KEY (`id`,`scope`),
                                  KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_store`
--

LOCK TABLES `settings_store` WRITE;
/*!40000 ALTER TABLE `settings_store` DISABLE KEYS */;
INSERT INTO `settings_store` VALUES
                                 ('BUNDLE_INSTALLED__Pimcore\\Bundle\\DataHubBundle\\PimcoreDataHubBundle','pimcore','1','bool'),
                                 ('BUNDLE_INSTALLED__Pimcore\\Bundle\\DataImporterBundle\\PimcoreDataImporterBundle','pimcore','1','bool');
/*!40000 ALTER TABLE `settings_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
                         `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                         `mainDomain` varchar(255) DEFAULT NULL,
                         `domains` text DEFAULT NULL,
                         `rootId` int(11) unsigned DEFAULT NULL,
                         `errorDocument` varchar(255) DEFAULT NULL,
                         `localizedErrorDocuments` text DEFAULT NULL,
                         `redirectToMainDomain` tinyint(1) DEFAULT NULL,
                         `creationDate` int(11) unsigned DEFAULT 0,
                         `modificationDate` int(11) unsigned DEFAULT 0,
                         PRIMARY KEY (`id`),
                         UNIQUE KEY `rootId` (`rootId`),
                         CONSTRAINT `fk_sites_documents` FOREIGN KEY (`rootId`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
                        `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                        `parentId` int(10) unsigned DEFAULT NULL,
                        `idPath` varchar(190) DEFAULT NULL,
                        `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                        PRIMARY KEY (`id`),
                        UNIQUE KEY `idPath_name` (`idPath`,`name`),
                        KEY `idpath` (`idPath`),
                        KEY `parentid` (`parentId`),
                        KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags_assignment`
--

DROP TABLE IF EXISTS `tags_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags_assignment` (
                                   `tagid` int(10) unsigned NOT NULL DEFAULT 0,
                                   `cid` int(10) NOT NULL DEFAULT 0,
                                   `ctype` enum('document','asset','object') NOT NULL,
                                   PRIMARY KEY (`tagid`,`cid`,`ctype`),
                                   KEY `ctype` (`ctype`),
                                   KEY `ctype_cid` (`cid`,`ctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags_assignment`
--

LOCK TABLES `tags_assignment` WRITE;
/*!40000 ALTER TABLE `tags_assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `targeting_rules`
--

DROP TABLE IF EXISTS `targeting_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targeting_rules` (
                                   `id` int(11) NOT NULL AUTO_INCREMENT,
                                   `name` varchar(255) NOT NULL DEFAULT '',
                                   `description` text DEFAULT NULL,
                                   `scope` varchar(50) DEFAULT NULL,
                                   `active` tinyint(1) DEFAULT NULL,
                                   `prio` smallint(5) unsigned NOT NULL DEFAULT 0,
                                   `conditions` longtext DEFAULT NULL,
                                   `actions` longtext DEFAULT NULL,
                                   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `targeting_rules`
--

LOCK TABLES `targeting_rules` WRITE;
/*!40000 ALTER TABLE `targeting_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `targeting_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `targeting_storage`
--

DROP TABLE IF EXISTS `targeting_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targeting_storage` (
                                     `visitorId` varchar(100) NOT NULL,
                                     `scope` varchar(50) NOT NULL,
                                     `name` varchar(100) NOT NULL,
                                     `value` text DEFAULT NULL,
                                     `creationDate` datetime DEFAULT NULL,
                                     `modificationDate` datetime DEFAULT NULL,
                                     PRIMARY KEY (`visitorId`,`scope`,`name`),
                                     KEY `targeting_storage_scope_index` (`scope`),
                                     KEY `targeting_storage_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `targeting_storage`
--

LOCK TABLES `targeting_storage` WRITE;
/*!40000 ALTER TABLE `targeting_storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `targeting_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `targeting_target_groups`
--

DROP TABLE IF EXISTS `targeting_target_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `targeting_target_groups` (
                                           `id` int(11) NOT NULL AUTO_INCREMENT,
                                           `name` varchar(255) NOT NULL DEFAULT '',
                                           `description` text DEFAULT NULL,
                                           `threshold` int(11) DEFAULT NULL,
                                           `active` tinyint(1) DEFAULT NULL,
                                           PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `targeting_target_groups`
--

LOCK TABLES `targeting_target_groups` WRITE;
/*!40000 ALTER TABLE `targeting_target_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `targeting_target_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp_store`
--

DROP TABLE IF EXISTS `tmp_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_store` (
                             `id` varchar(190) NOT NULL DEFAULT '',
                             `tag` varchar(190) DEFAULT NULL,
                             `data` longtext DEFAULT NULL,
                             `serialized` tinyint(2) NOT NULL DEFAULT 0,
                             `date` int(11) unsigned DEFAULT NULL,
                             `expiryDate` int(11) unsigned DEFAULT NULL,
                             PRIMARY KEY (`id`),
                             KEY `tag` (`tag`),
                             KEY `date` (`date`),
                             KEY `expiryDate` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp_store`
--

LOCK TABLES `tmp_store` WRITE;
/*!40000 ALTER TABLE `tmp_store` DISABLE KEYS */;
INSERT INTO `tmp_store` VALUES
                            ('log-usagelog.log',NULL,'1663884002',0,1663884002,1664488802),
                            ('maintenance.pid',NULL,'1664434802',0,1664434802,1665039602);
/*!40000 ALTER TABLE `tmp_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations_admin`
--

DROP TABLE IF EXISTS `translations_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations_admin` (
                                      `key` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
                                      `type` varchar(10) DEFAULT NULL,
                                      `language` varchar(10) NOT NULL DEFAULT '',
                                      `text` text DEFAULT NULL,
                                      `creationDate` int(11) unsigned DEFAULT NULL,
                                      `modificationDate` int(11) unsigned DEFAULT NULL,
                                      `userOwner` int(11) unsigned DEFAULT NULL,
                                      `userModification` int(11) unsigned DEFAULT NULL,
                                      PRIMARY KEY (`key`,`language`),
                                      KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations_admin`
--

LOCK TABLES `translations_admin` WRITE;
/*!40000 ALTER TABLE `translations_admin` DISABLE KEYS */;
INSERT INTO `translations_admin` VALUES
                                     ('API key does not satisfy the minimum length of 16 characters','simple','cs','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','de','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','en','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','es','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','fa','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','fr','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','hu','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','it','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','ja','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','nl','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','pl','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','pt','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','pt_BR','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','ru','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','sk','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','sv','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','sv_FI','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','th','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','tr','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','uk','',1659950773,1659950773,NULL,NULL),
                                     ('API key does not satisfy the minimum length of 16 characters','simple','zh_Hans','',1659950773,1659950773,NULL,NULL),
                                     ('Alt','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('Alt','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('Ctrl','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('English','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('Shift','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('The configuration was modified during editing, please reload the configuration and make your changes again','simple','en','',1659951986,1659951986,NULL,NULL),
                                     ('clear_fullpage_cache','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('clear_fullpage_cache','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('delete_message_advanced','simple','en','',1664796920,1664796920,NULL,NULL),
                                     ('down','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('down','simple','zh_Hans','',1658738504,1658738504,NULL,NULL),
                                     ('efwe','simple','cs','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','de','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','en','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','es','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','fa','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','fr','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','hu','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','it','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','ja','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','nl','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','pl','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','pt','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','pt_BR','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','ru','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','sk','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','sv','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','sv_FI','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','th','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','tr','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','uk','efwe',1658495671,1658495671,NULL,NULL),
                                     ('efwe','simple','zh_Hans','efwe',1658495671,1658495671,NULL,NULL),
                                     ('global','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('global','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('ignoreCase','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('keybinding_tagManager','simple','cs','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','de','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','en','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','es','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','fa','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','fr','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','hu','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','it','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','ja','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','nl','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','pl','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','pt','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','pt_BR','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','ru','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','sk','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','sv','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','sv_FI','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','th','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','tr','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','uk','',1658738505,1658738505,NULL,NULL),
                                     ('keybinding_tagManager','simple','zh_Hans','',1658738505,1658738505,NULL,NULL),
                                     ('login','simple','en','',1657535487,1657535487,NULL,NULL),
                                     ('login','simple','nl','',1657535487,1657535487,NULL,NULL),
                                     ('multiline','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('multiline','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('sticky','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','cs','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','de','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','en','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','es','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','fa','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','fr','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','hu','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','it','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','ja','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','nl','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','pl','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','pt','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','pt_BR','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','ru','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','sk','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','sv','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','sv_FI','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','th','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','tr','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','uk','',1658495709,1658495709,NULL,NULL),
                                     ('unicode','simple','zh_Hans','',1658495709,1658495709,NULL,NULL),
                                     ('up','simple','cs','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','de','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','en','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','es','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','fa','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','fr','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','hu','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','it','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','ja','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','nl','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','pl','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','pt','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','pt_BR','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','ru','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','sk','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','sv','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','sv_FI','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','th','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','tr','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','uk','',1658738504,1658738504,NULL,NULL),
                                     ('up','simple','zh_Hans','',1658738504,1658738504,NULL,NULL);
/*!40000 ALTER TABLE `translations_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations_messages`
--

DROP TABLE IF EXISTS `translations_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations_messages` (
                                         `key` varchar(190) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
                                         `type` varchar(10) DEFAULT NULL,
                                         `language` varchar(10) NOT NULL DEFAULT '',
                                         `text` text DEFAULT NULL,
                                         `creationDate` int(11) unsigned DEFAULT NULL,
                                         `modificationDate` int(11) unsigned DEFAULT NULL,
                                         `userOwner` int(11) unsigned DEFAULT NULL,
                                         `userModification` int(11) unsigned DEFAULT NULL,
                                         PRIMARY KEY (`key`,`language`),
                                         KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations_messages`
--

LOCK TABLES `translations_messages` WRITE;
/*!40000 ALTER TABLE `translations_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `translations_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tree_locks`
--

DROP TABLE IF EXISTS `tree_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tree_locks` (
                              `id` int(11) NOT NULL DEFAULT 0,
                              `type` enum('asset','document','object') NOT NULL DEFAULT 'asset',
                              `locked` enum('self','propagate') DEFAULT NULL,
                              PRIMARY KEY (`id`,`type`),
                              KEY `type` (`type`),
                              KEY `locked` (`locked`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tree_locks`
--

LOCK TABLES `tree_locks` WRITE;
/*!40000 ALTER TABLE `tree_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tree_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
                         `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                         `parentId` int(11) unsigned DEFAULT NULL,
                         `type` enum('user','userfolder','role','rolefolder') NOT NULL DEFAULT 'user',
                         `name` varchar(50) DEFAULT NULL,
                         `password` varchar(190) DEFAULT NULL,
                         `firstname` varchar(255) DEFAULT NULL,
                         `lastname` varchar(255) DEFAULT NULL,
                         `email` varchar(255) DEFAULT NULL,
                         `language` varchar(10) DEFAULT NULL,
                         `contentLanguages` longtext DEFAULT NULL,
                         `admin` tinyint(1) unsigned DEFAULT 0,
                         `active` tinyint(1) unsigned DEFAULT 1,
                         `permissions` text DEFAULT NULL,
                         `roles` varchar(1000) DEFAULT NULL,
                         `welcomescreen` tinyint(1) DEFAULT NULL,
                         `closeWarning` tinyint(1) DEFAULT NULL,
                         `memorizeTabs` tinyint(1) DEFAULT NULL,
                         `allowDirtyClose` tinyint(1) unsigned DEFAULT 1,
                         `docTypes` text DEFAULT NULL,
                         `classes` text DEFAULT NULL,
                         `twoFactorAuthentication` varchar(255) DEFAULT NULL,
                         `activePerspective` varchar(255) DEFAULT NULL,
                         `perspectives` longtext DEFAULT NULL,
                         `websiteTranslationLanguagesEdit` longtext DEFAULT NULL,
                         `websiteTranslationLanguagesView` longtext DEFAULT NULL,
                         `lastLogin` int(11) unsigned DEFAULT NULL,
                         `keyBindings` text DEFAULT NULL,
                         PRIMARY KEY (`id`),
                         UNIQUE KEY `type_name` (`type`,`name`),
                         KEY `parentId` (`parentId`),
                         KEY `name` (`name`),
                         KEY `password` (`password`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
                        (0,0,'user','system',NULL,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
                        (2,0,'user','admin','$2y$10$0WXFQQqiNIwFOLixmcPadOrkjp0Sa2xV6.WWNzM8dVUhAzybMxACG','','','','en','en',1,1,'admin_translations,application_logging,assets,asset_metadata,classes,clear_cache,clear_fullpage_cache,clear_temp_files,dashboards,documents,document_types,emails,gdpr_data_extractor,glossary,http_errors,notes_events,notifications,notifications_send,objects,objects_sort_method,plugins,predefined_properties,recyclebin,redirects,reports,reports_config,robots.txt,routes,seemode,seo_document_editor,share_configurations,sites,system_settings,tags_assignment,tags_configuration,tags_search,targeting,thumbnails,translations,users,web2print_settings,website_settings,workflow_details','',0,1,1,0,'','','{\"required\":false,\"enabled\":false,\"secret\":\"\",\"type\":\"\"}',NULL,'','','',1664795635,'[{\"action\":\"save\",\"key\":83,\"ctrl\":true},{\"action\":\"publish\",\"key\":80,\"ctrl\":true,\"shift\":true},{\"action\":\"unpublish\",\"key\":85,\"ctrl\":true,\"shift\":true},{\"action\":\"rename\",\"key\":82,\"alt\":true,\"shift\":true},{\"action\":\"refresh\",\"key\":116},{\"action\":\"openDocument\",\"key\":68,\"ctrl\":true,\"shift\":true},{\"action\":\"openAsset\",\"key\":65,\"ctrl\":true,\"shift\":true},{\"action\":\"openObject\",\"key\":79,\"ctrl\":true,\"shift\":true},{\"action\":\"openClassEditor\",\"key\":67,\"ctrl\":true,\"shift\":true},{\"action\":\"openInTree\",\"key\":76,\"ctrl\":true,\"shift\":true},{\"action\":\"showMetaInfo\",\"key\":73,\"alt\":true},{\"action\":\"searchDocument\",\"key\":87,\"alt\":true},{\"action\":\"searchAsset\",\"key\":65,\"alt\":true},{\"action\":\"searchObject\",\"key\":79,\"alt\":true},{\"action\":\"showElementHistory\",\"key\":72,\"alt\":true},{\"action\":\"closeAllTabs\",\"key\":84,\"alt\":true},{\"action\":\"searchAndReplaceAssignments\",\"key\":83,\"alt\":true},{\"action\":\"glossary\",\"key\":71,\"shift\":true,\"alt\":true},{\"action\":\"redirects\",\"key\":82,\"ctrl\":false,\"alt\":true},{\"action\":\"sharedTranslations\",\"key\":84,\"ctrl\":true,\"alt\":true},{\"action\":\"recycleBin\",\"key\":82,\"ctrl\":true,\"alt\":true},{\"action\":\"notesEvents\",\"key\":78,\"ctrl\":true,\"alt\":true},{\"action\":\"applicationLogger\",\"key\":76,\"ctrl\":true,\"alt\":true},{\"action\":\"reports\",\"key\":77,\"ctrl\":true,\"alt\":true},{\"action\":\"tagManager\",\"key\":72,\"ctrl\":true,\"alt\":true},{\"action\":\"seoDocumentEditor\",\"key\":83,\"ctrl\":true,\"alt\":true},{\"action\":\"robots\",\"key\":74,\"ctrl\":true,\"alt\":true},{\"action\":\"httpErrorLog\",\"key\":79,\"ctrl\":true,\"alt\":true},{\"action\":\"customReports\",\"key\":67,\"ctrl\":true,\"alt\":true},{\"action\":\"tagConfiguration\",\"key\":78,\"ctrl\":true,\"alt\":true},{\"action\":\"users\",\"key\":85,\"ctrl\":true,\"alt\":true},{\"action\":\"roles\",\"key\":80,\"ctrl\":true,\"alt\":true},{\"action\":\"clearAllCaches\",\"key\":81,\"ctrl\":false,\"alt\":true},{\"action\":\"clearDataCache\",\"key\":67,\"ctrl\":false,\"alt\":true},{\"action\":\"quickSearch\",\"key\":70,\"ctrl\":true,\"shift\":true}]'),
                        (3,0,'userfolder','SSO',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
                        (4,3,'userfolder','Youwe-OneLogin',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
                        (5,NULL,'role','OneLogin',NULL,NULL,NULL,NULL,NULL,NULL,0,1,'',NULL,NULL,NULL,NULL,1,'','',NULL,NULL,'','','',NULL,NULL),
                        (6,4,'user','j.mattar@youweagency.com-onelogin','968d5297dc517bfb4badf2be55ff02f57efb878b5dc8a12d82150b8a035eb7f539c9c458807800646705011c33683219c52b2e5e866440e4ad81f0522d66650a042f4fbe72ae21579f33bdb9a136ada0e77260f18e0531cc9ea81c240318f8','Jean','Mattar','j.mattar@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',0,NULL),
                        (7,4,'user','j.groefsema@youweagency.com-onelogin','b2cec2a962088be5ba5c983d02438ba1db747b2a1734568c25763bb60a08562900671721ea648bf757136d9821326250d38a4015a24ac76baa458aa65ce4614204950c701996022e2ee69b31958bf52c9f965953727b731450e9157156850d','Jeffrey','Groefsema','j.groefsema@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',0,NULL),
                        (8,4,'user','m.mijailovic@youweagency.com-onelogin','557a4fa089e9a91039bc6a907ae29392c645ce899779a1bf4a97c10c02fcfcc7c8ece3f3363b9213985fb25922260e72e9f7ae5fe8cc0355a4e3139e84da7c473ec4572a81090ce766f8c3bc78135078a717b8e5e7aa36c655cb3cebdfa85c','Marko','Mijailovic','m.mijailovic@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',0,NULL),
                        (10,4,'user','k.ovsiannikova@youweagency.com-onelogin','cd1803398b52318e14d5b38f5726155434b34c5b64b993150d54dfa41ce8fd50a50550df1cfb60da77aba589c31cae07e2fd54aa84d4aa82d30c73097c5ac777865e00d3ceb50e4fbb63f81514ef317f4535fe96be2bc88d85282bd90cecbd','Kseniia','Ovsiannikova','k.ovsiannikova@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',NULL,NULL),
                        (11,4,'user','b.memic@youweagency.com-onelogin','d5f9ecf308f6bde20fda1808c9c01a23cb6642921a869e8f6735321b7944a658eac5ed433d2d53ec7e23700ad31016087726086bc07c83add5de46a418e97188eb04188dc660dccb449c9b024f13a2e51b3380b8ceb13f7dfe9cea9825408c','Bojan','Memic','b.memic@youweagency.com','en',NULL,1,1,'','5',0,1,1,0,'','','null',NULL,'','','',0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_permission_definitions`
--

DROP TABLE IF EXISTS `users_permission_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_permission_definitions` (
                                                `key` varchar(50) NOT NULL DEFAULT '',
                                                `category` varchar(50) NOT NULL DEFAULT '',
                                                PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_permission_definitions`
--

LOCK TABLES `users_permission_definitions` WRITE;
/*!40000 ALTER TABLE `users_permission_definitions` DISABLE KEYS */;
INSERT INTO `users_permission_definitions` VALUES
                                               ('admin_translations',''),
                                               ('application_logging',''),
                                               ('assets',''),
                                               ('asset_metadata',''),
                                               ('classes',''),
                                               ('clear_cache',''),
                                               ('clear_fullpage_cache',''),
                                               ('clear_temp_files',''),
                                               ('dashboards',''),
                                               ('documents',''),
                                               ('document_types',''),
                                               ('emails',''),
                                               ('gdpr_data_extractor',''),
                                               ('glossary',''),
                                               ('http_errors',''),
                                               ('notes_events',''),
                                               ('notifications',''),
                                               ('notifications_send',''),
                                               ('objects',''),
                                               ('objects_sort_method',''),
                                               ('plugins',''),
                                               ('plugin_datahub_adapter_dataImporterDataObject','Datahub'),
                                               ('plugin_datahub_adapter_graphql','Datahub'),
                                               ('plugin_datahub_admin','Datahub'),
                                               ('plugin_datahub_config','Datahub'),
                                               ('predefined_properties',''),
                                               ('recyclebin',''),
                                               ('redirects',''),
                                               ('reports',''),
                                               ('reports_config',''),
                                               ('robots.txt',''),
                                               ('routes',''),
                                               ('seemode',''),
                                               ('seo_document_editor',''),
                                               ('share_configurations',''),
                                               ('sites',''),
                                               ('system_settings',''),
                                               ('tags_assignment',''),
                                               ('tags_configuration',''),
                                               ('tags_search',''),
                                               ('targeting',''),
                                               ('thumbnails',''),
                                               ('translations',''),
                                               ('users',''),
                                               ('web2print_settings',''),
                                               ('website_settings',''),
                                               ('workflow_details','');
/*!40000 ALTER TABLE `users_permission_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_asset`
--

DROP TABLE IF EXISTS `users_workspaces_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_workspaces_asset` (
                                          `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                          `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                                          `userId` int(11) unsigned NOT NULL DEFAULT 0,
                                          `list` tinyint(1) DEFAULT 0,
                                          `view` tinyint(1) DEFAULT 0,
                                          `publish` tinyint(1) DEFAULT 0,
                                          `delete` tinyint(1) DEFAULT 0,
                                          `rename` tinyint(1) DEFAULT 0,
                                          `create` tinyint(1) DEFAULT 0,
                                          `settings` tinyint(1) DEFAULT 0,
                                          `versions` tinyint(1) DEFAULT 0,
                                          `properties` tinyint(1) DEFAULT 0,
                                          PRIMARY KEY (`cid`,`userId`),
                                          UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
                                          KEY `userId` (`userId`),
                                          CONSTRAINT `fk_users_workspaces_asset_assets` FOREIGN KEY (`cid`) REFERENCES `assets` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
                                          CONSTRAINT `fk_users_workspaces_asset_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_asset`
--

LOCK TABLES `users_workspaces_asset` WRITE;
/*!40000 ALTER TABLE `users_workspaces_asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_document`
--

DROP TABLE IF EXISTS `users_workspaces_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_workspaces_document` (
                                             `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                             `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                                             `userId` int(11) unsigned NOT NULL DEFAULT 0,
                                             `list` tinyint(1) unsigned DEFAULT 0,
                                             `view` tinyint(1) unsigned DEFAULT 0,
                                             `save` tinyint(1) unsigned DEFAULT 0,
                                             `publish` tinyint(1) unsigned DEFAULT 0,
                                             `unpublish` tinyint(1) unsigned DEFAULT 0,
                                             `delete` tinyint(1) unsigned DEFAULT 0,
                                             `rename` tinyint(1) unsigned DEFAULT 0,
                                             `create` tinyint(1) unsigned DEFAULT 0,
                                             `settings` tinyint(1) unsigned DEFAULT 0,
                                             `versions` tinyint(1) unsigned DEFAULT 0,
                                             `properties` tinyint(1) unsigned DEFAULT 0,
                                             PRIMARY KEY (`cid`,`userId`),
                                             UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
                                             KEY `userId` (`userId`),
                                             CONSTRAINT `fk_users_workspaces_document_documents` FOREIGN KEY (`cid`) REFERENCES `documents` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
                                             CONSTRAINT `fk_users_workspaces_document_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_document`
--

LOCK TABLES `users_workspaces_document` WRITE;
/*!40000 ALTER TABLE `users_workspaces_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_workspaces_object`
--

DROP TABLE IF EXISTS `users_workspaces_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_workspaces_object` (
                                           `cid` int(11) unsigned NOT NULL DEFAULT 0,
                                           `cpath` varchar(765) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
                                           `userId` int(11) unsigned NOT NULL DEFAULT 0,
                                           `list` tinyint(1) unsigned DEFAULT 0,
                                           `view` tinyint(1) unsigned DEFAULT 0,
                                           `save` tinyint(1) unsigned DEFAULT 0,
                                           `publish` tinyint(1) unsigned DEFAULT 0,
                                           `unpublish` tinyint(1) unsigned DEFAULT 0,
                                           `delete` tinyint(1) unsigned DEFAULT 0,
                                           `rename` tinyint(1) unsigned DEFAULT 0,
                                           `create` tinyint(1) unsigned DEFAULT 0,
                                           `settings` tinyint(1) unsigned DEFAULT 0,
                                           `versions` tinyint(1) unsigned DEFAULT 0,
                                           `properties` tinyint(1) unsigned DEFAULT 0,
                                           `lEdit` text DEFAULT NULL,
                                           `lView` text DEFAULT NULL,
                                           `layouts` text DEFAULT NULL,
                                           PRIMARY KEY (`cid`,`userId`),
                                           UNIQUE KEY `cpath_userId` (`cpath`,`userId`),
                                           KEY `userId` (`userId`),
                                           CONSTRAINT `fk_users_workspaces_object_objects` FOREIGN KEY (`cid`) REFERENCES `objects` (`o_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
                                           CONSTRAINT `fk_users_workspaces_object_users` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_workspaces_object`
--

LOCK TABLES `users_workspaces_object` WRITE;
/*!40000 ALTER TABLE `users_workspaces_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_workspaces_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uuids`
--

DROP TABLE IF EXISTS `uuids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uuids` (
                         `uuid` char(36) NOT NULL,
                         `itemId` int(11) unsigned NOT NULL,
                         `type` varchar(25) NOT NULL,
                         `instanceIdentifier` varchar(50) NOT NULL,
                         PRIMARY KEY (`uuid`,`itemId`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uuids`
--

LOCK TABLES `uuids` WRITE;
/*!40000 ALTER TABLE `uuids` DISABLE KEYS */;
/*!40000 ALTER TABLE `uuids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `versions` (
                            `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                            `cid` int(11) unsigned DEFAULT NULL,
                            `ctype` enum('document','asset','object') DEFAULT NULL,
                            `userId` int(11) unsigned DEFAULT NULL,
                            `note` text DEFAULT NULL,
                            `stackTrace` text DEFAULT NULL,
                            `date` int(11) unsigned DEFAULT NULL,
                            `public` tinyint(1) unsigned NOT NULL DEFAULT 0,
                            `serialized` tinyint(1) unsigned DEFAULT 0,
                            `versionCount` int(10) unsigned NOT NULL DEFAULT 0,
                            `binaryFileHash` varchar(128) CHARACTER SET ascii DEFAULT NULL,
                            `binaryFileId` bigint(20) unsigned DEFAULT NULL,
                            `autoSave` tinyint(4) NOT NULL DEFAULT 0,
                            `storageType` varchar(5) NOT NULL,
                            PRIMARY KEY (`id`),
                            KEY `cid` (`cid`),
                            KEY `ctype_cid` (`ctype`,`cid`),
                            KEY `date` (`date`),
                            KEY `binaryFileHash` (`binaryFileHash`),
                            KEY `autoSave` (`autoSave`),
                            KEY `stackTrace` (`stackTrace`(1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webdav_locks`
--

DROP TABLE IF EXISTS `webdav_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webdav_locks` (
                                `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                                `owner` varchar(100) DEFAULT NULL,
                                `timeout` int(10) unsigned DEFAULT NULL,
                                `created` int(11) DEFAULT NULL,
                                `token` varbinary(100) DEFAULT NULL,
                                `scope` tinyint(4) DEFAULT NULL,
                                `depth` tinyint(4) DEFAULT NULL,
                                `uri` varbinary(1000) DEFAULT NULL,
                                PRIMARY KEY (`id`),
                                KEY `token` (`token`),
                                KEY `uri` (`uri`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webdav_locks`
--

LOCK TABLES `webdav_locks` WRITE;
/*!40000 ALTER TABLE `webdav_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webdav_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_settings`
--

DROP TABLE IF EXISTS `website_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website_settings` (
                                    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                                    `name` varchar(190) NOT NULL DEFAULT '',
                                    `type` enum('text','document','asset','object','bool') DEFAULT NULL,
                                    `data` text DEFAULT NULL,
                                    `language` varchar(15) NOT NULL DEFAULT '',
                                    `siteId` int(11) unsigned DEFAULT NULL,
                                    `creationDate` int(11) unsigned DEFAULT 0,
                                    `modificationDate` int(11) unsigned DEFAULT 0,
                                    PRIMARY KEY (`id`),
                                    KEY `name` (`name`),
                                    KEY `siteId` (`siteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_settings`
--

LOCK TABLES `website_settings` WRITE;
/*!40000 ALTER TABLE `website_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `website_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-03 13:35:34

INSERT IGNORE INTO quantityvalue_units (`id`, `group`, abbreviation, longname, baseunit, factor, conversionOffset, reference, converter) VALUES ('mlt', '', 'ml', 'millilitre', null, null, null, '', '');
INSERT IGNORE INTO quantityvalue_units (`id`, `group`, abbreviation, longname, baseunit, factor, conversionOffset, reference, converter) VALUES ('clt', '', 'cl', 'centilitre', 'mlt', 10, null, '', '');
INSERT IGNORE INTO quantityvalue_units (`id`, `group`, abbreviation, longname, baseunit, factor, conversionOffset, reference, converter) VALUES ('ea', '', 'ea', 'each', null, null, null, '', '');
INSERT IGNORE INTO quantityvalue_units (`id`, `group`, abbreviation, longname, baseunit, factor, conversionOffset, reference, converter) VALUES ('grm', '', 'g', 'gram', null, null, null, '', '');
INSERT IGNORE INTO quantityvalue_units (`id`, `group`, abbreviation, longname, baseunit, factor, conversionOffset, reference, converter) VALUES ('kgm', '', 'kg', 'kilogram', 'grm', 1000, null, '', '');
INSERT IGNORE INTO quantityvalue_units (`id`, `group`, abbreviation, longname, baseunit, factor, conversionOffset, reference, converter) VALUES ('ltr', '', 'l', 'litre', 'mlt', 1000, null, '', '');
INSERT IGNORE INTO quantityvalue_units (`id`, `group`, abbreviation, longname, baseunit, factor, conversionOffset, reference, converter) VALUES ('pcs', '', 'pcs', 'pieces', null, null, null, '', '');

UPDATE users
SET permissions = 'admin_translations,application_logging,assets,asset_metadata,classes,clear_cache,clear_fullpage_cache,clear_temp_files,dashboards,documents,document_types,emails,gdpr_data_extractor,glossary,http_errors,notes_events,notifications,notifications_send,objects,objects_sort_method,plugins,predefined_properties,recyclebin,redirects,reports,reports_config,robots.txt,routes,seemode,seo_document_editor,share_configurations,sites,system_settings,tags_assignment,tags_configuration,tags_search,targeting,thumbnails,translations,users,web2print_settings,website_settings,workflow_details'
WHERE id = 2;
